package com.example.baha_platform

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
