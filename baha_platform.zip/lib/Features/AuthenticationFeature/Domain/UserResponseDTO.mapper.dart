// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'UserResponseDTO.dart';

class UserResponseDTOMapper extends ClassMapperBase<UserResponseDTO> {
  UserResponseDTOMapper._();

  static UserResponseDTOMapper? _instance;
  static UserResponseDTOMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = UserResponseDTOMapper._());
      UserRoleEnumMapper.ensureInitialized();
      LocalizedStringMapper.ensureInitialized();
      ShopTypeEnumMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'UserResponseDTO';

  static String _$userId(UserResponseDTO v) => v.userId;
  static const Field<UserResponseDTO, String> _f$userId =
      Field('userId', _$userId);
  static String _$personalImageURL(UserResponseDTO v) => v.personalImageURL;
  static const Field<UserResponseDTO, String> _f$personalImageURL =
      Field('personalImageURL', _$personalImageURL);
  static String _$email(UserResponseDTO v) => v.email;
  static const Field<UserResponseDTO, String> _f$email =
      Field('email', _$email);
  static String _$phoneNumber(UserResponseDTO v) => v.phoneNumber;
  static const Field<UserResponseDTO, String> _f$phoneNumber =
      Field('phoneNumber', _$phoneNumber);
  static String _$addressString(UserResponseDTO v) => v.addressString;
  static const Field<UserResponseDTO, String> _f$addressString =
      Field('addressString', _$addressString);
  static String _$addressURL(UserResponseDTO v) => v.addressURL;
  static const Field<UserResponseDTO, String> _f$addressURL =
      Field('addressURL', _$addressURL);
  static String _$password(UserResponseDTO v) => v.password;
  static const Field<UserResponseDTO, String> _f$password =
      Field('password', _$password);
  static String _$name(UserResponseDTO v) => v.name;
  static const Field<UserResponseDTO, String> _f$name = Field('name', _$name);
  static UserRoleEnum _$userRole(UserResponseDTO v) => v.userRole;
  static const Field<UserResponseDTO, UserRoleEnum> _f$userRole =
      Field('userRole', _$userRole);
  static LocalizedString? _$description(UserResponseDTO v) => v.description;
  static const Field<UserResponseDTO, LocalizedString> _f$description =
      Field('description', _$description, opt: true);
  static ShopTypeEnum? _$shopType(UserResponseDTO v) => v.shopType;
  static const Field<UserResponseDTO, ShopTypeEnum> _f$shopType =
      Field('shopType', _$shopType, opt: true);
  static String? _$whatsAppPhoneNumber(UserResponseDTO v) =>
      v.whatsAppPhoneNumber;
  static const Field<UserResponseDTO, String> _f$whatsAppPhoneNumber =
      Field('whatsAppPhoneNumber', _$whatsAppPhoneNumber, opt: true);
  static bool? _$approved(UserResponseDTO v) => v.approved;
  static const Field<UserResponseDTO, bool> _f$approved =
      Field('approved', _$approved, opt: true);

  @override
  final MappableFields<UserResponseDTO> fields = const {
    #userId: _f$userId,
    #personalImageURL: _f$personalImageURL,
    #email: _f$email,
    #phoneNumber: _f$phoneNumber,
    #addressString: _f$addressString,
    #addressURL: _f$addressURL,
    #password: _f$password,
    #name: _f$name,
    #userRole: _f$userRole,
    #description: _f$description,
    #shopType: _f$shopType,
    #whatsAppPhoneNumber: _f$whatsAppPhoneNumber,
    #approved: _f$approved,
  };

  static UserResponseDTO _instantiate(DecodingData data) {
    return UserResponseDTO(
        userId: data.dec(_f$userId),
        personalImageURL: data.dec(_f$personalImageURL),
        email: data.dec(_f$email),
        phoneNumber: data.dec(_f$phoneNumber),
        addressString: data.dec(_f$addressString),
        addressURL: data.dec(_f$addressURL),
        password: data.dec(_f$password),
        name: data.dec(_f$name),
        userRole: data.dec(_f$userRole),
        description: data.dec(_f$description),
        shopType: data.dec(_f$shopType),
        whatsAppPhoneNumber: data.dec(_f$whatsAppPhoneNumber),
        approved: data.dec(_f$approved));
  }

  @override
  final Function instantiate = _instantiate;

  static UserResponseDTO fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<UserResponseDTO>(map);
  }

  static UserResponseDTO fromJson(String json) {
    return ensureInitialized().decodeJson<UserResponseDTO>(json);
  }
}

mixin UserResponseDTOMappable {
  String toJson() {
    return UserResponseDTOMapper.ensureInitialized()
        .encodeJson<UserResponseDTO>(this as UserResponseDTO);
  }

  Map<String, dynamic> toMap() {
    return UserResponseDTOMapper.ensureInitialized()
        .encodeMap<UserResponseDTO>(this as UserResponseDTO);
  }

  UserResponseDTOCopyWith<UserResponseDTO, UserResponseDTO, UserResponseDTO>
      get copyWith => _UserResponseDTOCopyWithImpl(
          this as UserResponseDTO, $identity, $identity);
  @override
  String toString() {
    return UserResponseDTOMapper.ensureInitialized()
        .stringifyValue(this as UserResponseDTO);
  }

  @override
  bool operator ==(Object other) {
    return UserResponseDTOMapper.ensureInitialized()
        .equalsValue(this as UserResponseDTO, other);
  }

  @override
  int get hashCode {
    return UserResponseDTOMapper.ensureInitialized()
        .hashValue(this as UserResponseDTO);
  }
}

extension UserResponseDTOValueCopy<$R, $Out>
    on ObjectCopyWith<$R, UserResponseDTO, $Out> {
  UserResponseDTOCopyWith<$R, UserResponseDTO, $Out> get $asUserResponseDTO =>
      $base.as((v, t, t2) => _UserResponseDTOCopyWithImpl(v, t, t2));
}

abstract class UserResponseDTOCopyWith<$R, $In extends UserResponseDTO, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>?
      get description;
  $R call(
      {String? userId,
      String? personalImageURL,
      String? email,
      String? phoneNumber,
      String? addressString,
      String? addressURL,
      String? password,
      String? name,
      UserRoleEnum? userRole,
      LocalizedString? description,
      ShopTypeEnum? shopType,
      String? whatsAppPhoneNumber,
      bool? approved});
  UserResponseDTOCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(
      Then<$Out2, $R2> t);
}

class _UserResponseDTOCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, UserResponseDTO, $Out>
    implements UserResponseDTOCopyWith<$R, UserResponseDTO, $Out> {
  _UserResponseDTOCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<UserResponseDTO> $mapper =
      UserResponseDTOMapper.ensureInitialized();
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>?
      get description =>
          $value.description?.copyWith.$chain((v) => call(description: v));
  @override
  $R call(
          {String? userId,
          String? personalImageURL,
          String? email,
          String? phoneNumber,
          String? addressString,
          String? addressURL,
          String? password,
          String? name,
          UserRoleEnum? userRole,
          Object? description = $none,
          Object? shopType = $none,
          Object? whatsAppPhoneNumber = $none,
          Object? approved = $none}) =>
      $apply(FieldCopyWithData({
        if (userId != null) #userId: userId,
        if (personalImageURL != null) #personalImageURL: personalImageURL,
        if (email != null) #email: email,
        if (phoneNumber != null) #phoneNumber: phoneNumber,
        if (addressString != null) #addressString: addressString,
        if (addressURL != null) #addressURL: addressURL,
        if (password != null) #password: password,
        if (name != null) #name: name,
        if (userRole != null) #userRole: userRole,
        if (description != $none) #description: description,
        if (shopType != $none) #shopType: shopType,
        if (whatsAppPhoneNumber != $none)
          #whatsAppPhoneNumber: whatsAppPhoneNumber,
        if (approved != $none) #approved: approved
      }));
  @override
  UserResponseDTO $make(CopyWithData data) => UserResponseDTO(
      userId: data.get(#userId, or: $value.userId),
      personalImageURL:
          data.get(#personalImageURL, or: $value.personalImageURL),
      email: data.get(#email, or: $value.email),
      phoneNumber: data.get(#phoneNumber, or: $value.phoneNumber),
      addressString: data.get(#addressString, or: $value.addressString),
      addressURL: data.get(#addressURL, or: $value.addressURL),
      password: data.get(#password, or: $value.password),
      name: data.get(#name, or: $value.name),
      userRole: data.get(#userRole, or: $value.userRole),
      description: data.get(#description, or: $value.description),
      shopType: data.get(#shopType, or: $value.shopType),
      whatsAppPhoneNumber:
          data.get(#whatsAppPhoneNumber, or: $value.whatsAppPhoneNumber),
      approved: data.get(#approved, or: $value.approved));

  @override
  UserResponseDTOCopyWith<$R2, UserResponseDTO, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _UserResponseDTOCopyWithImpl($value, $cast, t);
}

class CustomerOrderDataMapper extends ClassMapperBase<CustomerOrderData> {
  CustomerOrderDataMapper._();

  static CustomerOrderDataMapper? _instance;
  static CustomerOrderDataMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = CustomerOrderDataMapper._());
    }
    return _instance!;
  }

  @override
  final String id = 'CustomerOrderData';

  static String _$name(CustomerOrderData v) => v.name;
  static const Field<CustomerOrderData, String> _f$name = Field('name', _$name);
  static String? _$phoneNumber(CustomerOrderData v) => v.phoneNumber;
  static const Field<CustomerOrderData, String> _f$phoneNumber =
      Field('phoneNumber', _$phoneNumber);
  static String? _$address(CustomerOrderData v) => v.address;
  static const Field<CustomerOrderData, String> _f$address =
      Field('address', _$address);

  @override
  final MappableFields<CustomerOrderData> fields = const {
    #name: _f$name,
    #phoneNumber: _f$phoneNumber,
    #address: _f$address,
  };

  static CustomerOrderData _instantiate(DecodingData data) {
    return CustomerOrderData(
        name: data.dec(_f$name),
        phoneNumber: data.dec(_f$phoneNumber),
        address: data.dec(_f$address));
  }

  @override
  final Function instantiate = _instantiate;

  static CustomerOrderData fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<CustomerOrderData>(map);
  }

  static CustomerOrderData fromJson(String json) {
    return ensureInitialized().decodeJson<CustomerOrderData>(json);
  }
}

mixin CustomerOrderDataMappable {
  String toJson() {
    return CustomerOrderDataMapper.ensureInitialized()
        .encodeJson<CustomerOrderData>(this as CustomerOrderData);
  }

  Map<String, dynamic> toMap() {
    return CustomerOrderDataMapper.ensureInitialized()
        .encodeMap<CustomerOrderData>(this as CustomerOrderData);
  }

  CustomerOrderDataCopyWith<CustomerOrderData, CustomerOrderData,
          CustomerOrderData>
      get copyWith => _CustomerOrderDataCopyWithImpl(
          this as CustomerOrderData, $identity, $identity);
  @override
  String toString() {
    return CustomerOrderDataMapper.ensureInitialized()
        .stringifyValue(this as CustomerOrderData);
  }

  @override
  bool operator ==(Object other) {
    return CustomerOrderDataMapper.ensureInitialized()
        .equalsValue(this as CustomerOrderData, other);
  }

  @override
  int get hashCode {
    return CustomerOrderDataMapper.ensureInitialized()
        .hashValue(this as CustomerOrderData);
  }
}

extension CustomerOrderDataValueCopy<$R, $Out>
    on ObjectCopyWith<$R, CustomerOrderData, $Out> {
  CustomerOrderDataCopyWith<$R, CustomerOrderData, $Out>
      get $asCustomerOrderData =>
          $base.as((v, t, t2) => _CustomerOrderDataCopyWithImpl(v, t, t2));
}

abstract class CustomerOrderDataCopyWith<$R, $In extends CustomerOrderData,
    $Out> implements ClassCopyWith<$R, $In, $Out> {
  $R call({String? name, String? phoneNumber, String? address});
  CustomerOrderDataCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(
      Then<$Out2, $R2> t);
}

class _CustomerOrderDataCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, CustomerOrderData, $Out>
    implements CustomerOrderDataCopyWith<$R, CustomerOrderData, $Out> {
  _CustomerOrderDataCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<CustomerOrderData> $mapper =
      CustomerOrderDataMapper.ensureInitialized();
  @override
  $R call(
          {String? name,
          Object? phoneNumber = $none,
          Object? address = $none}) =>
      $apply(FieldCopyWithData({
        if (name != null) #name: name,
        if (phoneNumber != $none) #phoneNumber: phoneNumber,
        if (address != $none) #address: address
      }));
  @override
  CustomerOrderData $make(CopyWithData data) => CustomerOrderData(
      name: data.get(#name, or: $value.name),
      phoneNumber: data.get(#phoneNumber, or: $value.phoneNumber),
      address: data.get(#address, or: $value.address));

  @override
  CustomerOrderDataCopyWith<$R2, CustomerOrderData, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _CustomerOrderDataCopyWithImpl($value, $cast, t);
}
