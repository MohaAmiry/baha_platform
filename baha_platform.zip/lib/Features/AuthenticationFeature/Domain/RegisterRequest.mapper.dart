// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'RegisterRequest.dart';

class RegisterRequestMapper extends ClassMapperBase<RegisterRequest> {
  RegisterRequestMapper._();

  static RegisterRequestMapper? _instance;
  static RegisterRequestMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = RegisterRequestMapper._());
      ShopRegisterRequestMapper.ensureInitialized();
      CustomerRegisterRequestMapper.ensureInitialized();
      TouristGuideRegisterRequestMapper.ensureInitialized();
      UserRoleEnumMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'RegisterRequest';

  static String _$userId(RegisterRequest v) => v.userId;
  static const Field<RegisterRequest, String> _f$userId =
      Field('userId', _$userId);
  static String _$personalImageURL(RegisterRequest v) => v.personalImageURL;
  static const Field<RegisterRequest, String> _f$personalImageURL =
      Field('personalImageURL', _$personalImageURL);
  static String _$addressURL(RegisterRequest v) => v.addressURL;
  static const Field<RegisterRequest, String> _f$addressURL =
      Field('addressURL', _$addressURL);
  static String _$phoneNumber(RegisterRequest v) => v.phoneNumber;
  static const Field<RegisterRequest, String> _f$phoneNumber =
      Field('phoneNumber', _$phoneNumber);
  static String _$addressString(RegisterRequest v) => v.addressString;
  static const Field<RegisterRequest, String> _f$addressString =
      Field('addressString', _$addressString);
  static String _$name(RegisterRequest v) => v.name;
  static const Field<RegisterRequest, String> _f$name = Field('name', _$name);
  static String _$email(RegisterRequest v) => v.email;
  static const Field<RegisterRequest, String> _f$email =
      Field('email', _$email);
  static String _$password(RegisterRequest v) => v.password;
  static const Field<RegisterRequest, String> _f$password =
      Field('password', _$password);
  static UserRoleEnum _$userRole(RegisterRequest v) => v.userRole;
  static const Field<RegisterRequest, UserRoleEnum> _f$userRole =
      Field('userRole', _$userRole);

  @override
  final MappableFields<RegisterRequest> fields = const {
    #userId: _f$userId,
    #personalImageURL: _f$personalImageURL,
    #addressURL: _f$addressURL,
    #phoneNumber: _f$phoneNumber,
    #addressString: _f$addressString,
    #name: _f$name,
    #email: _f$email,
    #password: _f$password,
    #userRole: _f$userRole,
  };

  static RegisterRequest _instantiate(DecodingData data) {
    throw MapperException.missingConstructor('RegisterRequest');
  }

  @override
  final Function instantiate = _instantiate;

  static RegisterRequest fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<RegisterRequest>(map);
  }

  static RegisterRequest fromJson(String json) {
    return ensureInitialized().decodeJson<RegisterRequest>(json);
  }
}

mixin RegisterRequestMappable {
  String toJson();
  Map<String, dynamic> toMap();
  RegisterRequestCopyWith<RegisterRequest, RegisterRequest, RegisterRequest>
      get copyWith;
}

abstract class RegisterRequestCopyWith<$R, $In extends RegisterRequest, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  $R call(
      {String? userId,
      String? personalImageURL,
      String? addressURL,
      String? phoneNumber,
      String? addressString,
      String? name,
      String? email,
      String? password,
      UserRoleEnum? userRole});
  RegisterRequestCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(
      Then<$Out2, $R2> t);
}

class ShopRegisterRequestMapper extends ClassMapperBase<ShopRegisterRequest> {
  ShopRegisterRequestMapper._();

  static ShopRegisterRequestMapper? _instance;
  static ShopRegisterRequestMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = ShopRegisterRequestMapper._());
      RegisterRequestMapper.ensureInitialized();
      UserRoleEnumMapper.ensureInitialized();
      LocalizedStringMapper.ensureInitialized();
      ShopTypeEnumMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'ShopRegisterRequest';

  static String _$userId(ShopRegisterRequest v) => v.userId;
  static const Field<ShopRegisterRequest, String> _f$userId =
      Field('userId', _$userId);
  static String _$addressString(ShopRegisterRequest v) => v.addressString;
  static const Field<ShopRegisterRequest, String> _f$addressString =
      Field('addressString', _$addressString);
  static String _$addressURL(ShopRegisterRequest v) => v.addressURL;
  static const Field<ShopRegisterRequest, String> _f$addressURL =
      Field('addressURL', _$addressURL);
  static String _$personalImageURL(ShopRegisterRequest v) => v.personalImageURL;
  static const Field<ShopRegisterRequest, String> _f$personalImageURL =
      Field('personalImageURL', _$personalImageURL);
  static String _$name(ShopRegisterRequest v) => v.name;
  static const Field<ShopRegisterRequest, String> _f$name =
      Field('name', _$name);
  static String _$email(ShopRegisterRequest v) => v.email;
  static const Field<ShopRegisterRequest, String> _f$email =
      Field('email', _$email);
  static String _$password(ShopRegisterRequest v) => v.password;
  static const Field<ShopRegisterRequest, String> _f$password =
      Field('password', _$password);
  static String _$phoneNumber(ShopRegisterRequest v) => v.phoneNumber;
  static const Field<ShopRegisterRequest, String> _f$phoneNumber =
      Field('phoneNumber', _$phoneNumber);
  static UserRoleEnum _$userRole(ShopRegisterRequest v) => v.userRole;
  static const Field<ShopRegisterRequest, UserRoleEnum> _f$userRole =
      Field('userRole', _$userRole, opt: true, def: UserRoleEnum.shop);
  static LocalizedString _$description(ShopRegisterRequest v) => v.description;
  static const Field<ShopRegisterRequest, LocalizedString> _f$description =
      Field('description', _$description);
  static bool? _$approved(ShopRegisterRequest v) => v.approved;
  static const Field<ShopRegisterRequest, bool> _f$approved =
      Field('approved', _$approved, opt: true);
  static ShopTypeEnum _$shopType(ShopRegisterRequest v) => v.shopType;
  static const Field<ShopRegisterRequest, ShopTypeEnum> _f$shopType = Field(
      'shopType', _$shopType,
      opt: true, def: ShopTypeEnum.agriculturalShop);

  @override
  final MappableFields<ShopRegisterRequest> fields = const {
    #userId: _f$userId,
    #addressString: _f$addressString,
    #addressURL: _f$addressURL,
    #personalImageURL: _f$personalImageURL,
    #name: _f$name,
    #email: _f$email,
    #password: _f$password,
    #phoneNumber: _f$phoneNumber,
    #userRole: _f$userRole,
    #description: _f$description,
    #approved: _f$approved,
    #shopType: _f$shopType,
  };

  static ShopRegisterRequest _instantiate(DecodingData data) {
    return ShopRegisterRequest(
        userId: data.dec(_f$userId),
        addressString: data.dec(_f$addressString),
        addressURL: data.dec(_f$addressURL),
        personalImageURL: data.dec(_f$personalImageURL),
        name: data.dec(_f$name),
        email: data.dec(_f$email),
        password: data.dec(_f$password),
        phoneNumber: data.dec(_f$phoneNumber),
        userRole: data.dec(_f$userRole),
        description: data.dec(_f$description),
        approved: data.dec(_f$approved),
        shopType: data.dec(_f$shopType));
  }

  @override
  final Function instantiate = _instantiate;

  static ShopRegisterRequest fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<ShopRegisterRequest>(map);
  }

  static ShopRegisterRequest fromJson(String json) {
    return ensureInitialized().decodeJson<ShopRegisterRequest>(json);
  }
}

mixin ShopRegisterRequestMappable {
  String toJson() {
    return ShopRegisterRequestMapper.ensureInitialized()
        .encodeJson<ShopRegisterRequest>(this as ShopRegisterRequest);
  }

  Map<String, dynamic> toMap() {
    return ShopRegisterRequestMapper.ensureInitialized()
        .encodeMap<ShopRegisterRequest>(this as ShopRegisterRequest);
  }

  ShopRegisterRequestCopyWith<ShopRegisterRequest, ShopRegisterRequest,
          ShopRegisterRequest>
      get copyWith => _ShopRegisterRequestCopyWithImpl(
          this as ShopRegisterRequest, $identity, $identity);
  @override
  String toString() {
    return ShopRegisterRequestMapper.ensureInitialized()
        .stringifyValue(this as ShopRegisterRequest);
  }

  @override
  bool operator ==(Object other) {
    return ShopRegisterRequestMapper.ensureInitialized()
        .equalsValue(this as ShopRegisterRequest, other);
  }

  @override
  int get hashCode {
    return ShopRegisterRequestMapper.ensureInitialized()
        .hashValue(this as ShopRegisterRequest);
  }
}

extension ShopRegisterRequestValueCopy<$R, $Out>
    on ObjectCopyWith<$R, ShopRegisterRequest, $Out> {
  ShopRegisterRequestCopyWith<$R, ShopRegisterRequest, $Out>
      get $asShopRegisterRequest =>
          $base.as((v, t, t2) => _ShopRegisterRequestCopyWithImpl(v, t, t2));
}

abstract class ShopRegisterRequestCopyWith<$R, $In extends ShopRegisterRequest,
    $Out> implements RegisterRequestCopyWith<$R, $In, $Out> {
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get description;
  @override
  $R call(
      {String? userId,
      String? addressString,
      String? addressURL,
      String? personalImageURL,
      String? name,
      String? email,
      String? password,
      String? phoneNumber,
      UserRoleEnum? userRole,
      LocalizedString? description,
      bool? approved,
      ShopTypeEnum? shopType});
  ShopRegisterRequestCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(
      Then<$Out2, $R2> t);
}

class _ShopRegisterRequestCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, ShopRegisterRequest, $Out>
    implements ShopRegisterRequestCopyWith<$R, ShopRegisterRequest, $Out> {
  _ShopRegisterRequestCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<ShopRegisterRequest> $mapper =
      ShopRegisterRequestMapper.ensureInitialized();
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>
      get description =>
          $value.description.copyWith.$chain((v) => call(description: v));
  @override
  $R call(
          {String? userId,
          String? addressString,
          String? addressURL,
          String? personalImageURL,
          String? name,
          String? email,
          String? password,
          String? phoneNumber,
          UserRoleEnum? userRole,
          LocalizedString? description,
          Object? approved = $none,
          ShopTypeEnum? shopType}) =>
      $apply(FieldCopyWithData({
        if (userId != null) #userId: userId,
        if (addressString != null) #addressString: addressString,
        if (addressURL != null) #addressURL: addressURL,
        if (personalImageURL != null) #personalImageURL: personalImageURL,
        if (name != null) #name: name,
        if (email != null) #email: email,
        if (password != null) #password: password,
        if (phoneNumber != null) #phoneNumber: phoneNumber,
        if (userRole != null) #userRole: userRole,
        if (description != null) #description: description,
        if (approved != $none) #approved: approved,
        if (shopType != null) #shopType: shopType
      }));
  @override
  ShopRegisterRequest $make(CopyWithData data) => ShopRegisterRequest(
      userId: data.get(#userId, or: $value.userId),
      addressString: data.get(#addressString, or: $value.addressString),
      addressURL: data.get(#addressURL, or: $value.addressURL),
      personalImageURL:
          data.get(#personalImageURL, or: $value.personalImageURL),
      name: data.get(#name, or: $value.name),
      email: data.get(#email, or: $value.email),
      password: data.get(#password, or: $value.password),
      phoneNumber: data.get(#phoneNumber, or: $value.phoneNumber),
      userRole: data.get(#userRole, or: $value.userRole),
      description: data.get(#description, or: $value.description),
      approved: data.get(#approved, or: $value.approved),
      shopType: data.get(#shopType, or: $value.shopType));

  @override
  ShopRegisterRequestCopyWith<$R2, ShopRegisterRequest, $Out2>
      $chain<$R2, $Out2>(Then<$Out2, $R2> t) =>
          _ShopRegisterRequestCopyWithImpl($value, $cast, t);
}

class CustomerRegisterRequestMapper
    extends ClassMapperBase<CustomerRegisterRequest> {
  CustomerRegisterRequestMapper._();

  static CustomerRegisterRequestMapper? _instance;
  static CustomerRegisterRequestMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals
          .use(_instance = CustomerRegisterRequestMapper._());
      RegisterRequestMapper.ensureInitialized();
      UserRoleEnumMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'CustomerRegisterRequest';

  static String _$userId(CustomerRegisterRequest v) => v.userId;
  static const Field<CustomerRegisterRequest, String> _f$userId =
      Field('userId', _$userId);
  static String _$addressString(CustomerRegisterRequest v) => v.addressString;
  static const Field<CustomerRegisterRequest, String> _f$addressString =
      Field('addressString', _$addressString);
  static String _$personalImageURL(CustomerRegisterRequest v) =>
      v.personalImageURL;
  static const Field<CustomerRegisterRequest, String> _f$personalImageURL =
      Field('personalImageURL', _$personalImageURL);
  static String _$addressURL(CustomerRegisterRequest v) => v.addressURL;
  static const Field<CustomerRegisterRequest, String> _f$addressURL =
      Field('addressURL', _$addressURL);
  static String _$name(CustomerRegisterRequest v) => v.name;
  static const Field<CustomerRegisterRequest, String> _f$name =
      Field('name', _$name);
  static String _$email(CustomerRegisterRequest v) => v.email;
  static const Field<CustomerRegisterRequest, String> _f$email =
      Field('email', _$email);
  static String _$password(CustomerRegisterRequest v) => v.password;
  static const Field<CustomerRegisterRequest, String> _f$password =
      Field('password', _$password);
  static String _$phoneNumber(CustomerRegisterRequest v) => v.phoneNumber;
  static const Field<CustomerRegisterRequest, String> _f$phoneNumber =
      Field('phoneNumber', _$phoneNumber);
  static UserRoleEnum _$userRole(CustomerRegisterRequest v) => v.userRole;
  static const Field<CustomerRegisterRequest, UserRoleEnum> _f$userRole =
      Field('userRole', _$userRole, opt: true, def: UserRoleEnum.customer);

  @override
  final MappableFields<CustomerRegisterRequest> fields = const {
    #userId: _f$userId,
    #addressString: _f$addressString,
    #personalImageURL: _f$personalImageURL,
    #addressURL: _f$addressURL,
    #name: _f$name,
    #email: _f$email,
    #password: _f$password,
    #phoneNumber: _f$phoneNumber,
    #userRole: _f$userRole,
  };

  static CustomerRegisterRequest _instantiate(DecodingData data) {
    return CustomerRegisterRequest(
        userId: data.dec(_f$userId),
        addressString: data.dec(_f$addressString),
        personalImageURL: data.dec(_f$personalImageURL),
        addressURL: data.dec(_f$addressURL),
        name: data.dec(_f$name),
        email: data.dec(_f$email),
        password: data.dec(_f$password),
        phoneNumber: data.dec(_f$phoneNumber),
        userRole: data.dec(_f$userRole));
  }

  @override
  final Function instantiate = _instantiate;

  static CustomerRegisterRequest fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<CustomerRegisterRequest>(map);
  }

  static CustomerRegisterRequest fromJson(String json) {
    return ensureInitialized().decodeJson<CustomerRegisterRequest>(json);
  }
}

mixin CustomerRegisterRequestMappable {
  String toJson() {
    return CustomerRegisterRequestMapper.ensureInitialized()
        .encodeJson<CustomerRegisterRequest>(this as CustomerRegisterRequest);
  }

  Map<String, dynamic> toMap() {
    return CustomerRegisterRequestMapper.ensureInitialized()
        .encodeMap<CustomerRegisterRequest>(this as CustomerRegisterRequest);
  }

  CustomerRegisterRequestCopyWith<CustomerRegisterRequest,
          CustomerRegisterRequest, CustomerRegisterRequest>
      get copyWith => _CustomerRegisterRequestCopyWithImpl(
          this as CustomerRegisterRequest, $identity, $identity);
  @override
  String toString() {
    return CustomerRegisterRequestMapper.ensureInitialized()
        .stringifyValue(this as CustomerRegisterRequest);
  }

  @override
  bool operator ==(Object other) {
    return CustomerRegisterRequestMapper.ensureInitialized()
        .equalsValue(this as CustomerRegisterRequest, other);
  }

  @override
  int get hashCode {
    return CustomerRegisterRequestMapper.ensureInitialized()
        .hashValue(this as CustomerRegisterRequest);
  }
}

extension CustomerRegisterRequestValueCopy<$R, $Out>
    on ObjectCopyWith<$R, CustomerRegisterRequest, $Out> {
  CustomerRegisterRequestCopyWith<$R, CustomerRegisterRequest, $Out>
      get $asCustomerRegisterRequest => $base
          .as((v, t, t2) => _CustomerRegisterRequestCopyWithImpl(v, t, t2));
}

abstract class CustomerRegisterRequestCopyWith<
    $R,
    $In extends CustomerRegisterRequest,
    $Out> implements RegisterRequestCopyWith<$R, $In, $Out> {
  @override
  $R call(
      {String? userId,
      String? addressString,
      String? personalImageURL,
      String? addressURL,
      String? name,
      String? email,
      String? password,
      String? phoneNumber,
      UserRoleEnum? userRole});
  CustomerRegisterRequestCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(
      Then<$Out2, $R2> t);
}

class _CustomerRegisterRequestCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, CustomerRegisterRequest, $Out>
    implements
        CustomerRegisterRequestCopyWith<$R, CustomerRegisterRequest, $Out> {
  _CustomerRegisterRequestCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<CustomerRegisterRequest> $mapper =
      CustomerRegisterRequestMapper.ensureInitialized();
  @override
  $R call(
          {String? userId,
          String? addressString,
          String? personalImageURL,
          String? addressURL,
          String? name,
          String? email,
          String? password,
          String? phoneNumber,
          UserRoleEnum? userRole}) =>
      $apply(FieldCopyWithData({
        if (userId != null) #userId: userId,
        if (addressString != null) #addressString: addressString,
        if (personalImageURL != null) #personalImageURL: personalImageURL,
        if (addressURL != null) #addressURL: addressURL,
        if (name != null) #name: name,
        if (email != null) #email: email,
        if (password != null) #password: password,
        if (phoneNumber != null) #phoneNumber: phoneNumber,
        if (userRole != null) #userRole: userRole
      }));
  @override
  CustomerRegisterRequest $make(CopyWithData data) => CustomerRegisterRequest(
      userId: data.get(#userId, or: $value.userId),
      addressString: data.get(#addressString, or: $value.addressString),
      personalImageURL:
          data.get(#personalImageURL, or: $value.personalImageURL),
      addressURL: data.get(#addressURL, or: $value.addressURL),
      name: data.get(#name, or: $value.name),
      email: data.get(#email, or: $value.email),
      password: data.get(#password, or: $value.password),
      phoneNumber: data.get(#phoneNumber, or: $value.phoneNumber),
      userRole: data.get(#userRole, or: $value.userRole));

  @override
  CustomerRegisterRequestCopyWith<$R2, CustomerRegisterRequest, $Out2>
      $chain<$R2, $Out2>(Then<$Out2, $R2> t) =>
          _CustomerRegisterRequestCopyWithImpl($value, $cast, t);
}

class TouristGuideRegisterRequestMapper
    extends ClassMapperBase<TouristGuideRegisterRequest> {
  TouristGuideRegisterRequestMapper._();

  static TouristGuideRegisterRequestMapper? _instance;
  static TouristGuideRegisterRequestMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals
          .use(_instance = TouristGuideRegisterRequestMapper._());
      RegisterRequestMapper.ensureInitialized();
      UserRoleEnumMapper.ensureInitialized();
      LocalizedStringMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'TouristGuideRegisterRequest';

  static String _$userId(TouristGuideRegisterRequest v) => v.userId;
  static const Field<TouristGuideRegisterRequest, String> _f$userId =
      Field('userId', _$userId);
  static String _$addressString(TouristGuideRegisterRequest v) =>
      v.addressString;
  static const Field<TouristGuideRegisterRequest, String> _f$addressString =
      Field('addressString', _$addressString);
  static String _$name(TouristGuideRegisterRequest v) => v.name;
  static const Field<TouristGuideRegisterRequest, String> _f$name =
      Field('name', _$name);
  static String _$email(TouristGuideRegisterRequest v) => v.email;
  static const Field<TouristGuideRegisterRequest, String> _f$email =
      Field('email', _$email);
  static String _$password(TouristGuideRegisterRequest v) => v.password;
  static const Field<TouristGuideRegisterRequest, String> _f$password =
      Field('password', _$password);
  static String _$phoneNumber(TouristGuideRegisterRequest v) => v.phoneNumber;
  static const Field<TouristGuideRegisterRequest, String> _f$phoneNumber =
      Field('phoneNumber', _$phoneNumber);
  static String _$personalImageURL(TouristGuideRegisterRequest v) =>
      v.personalImageURL;
  static const Field<TouristGuideRegisterRequest, String> _f$personalImageURL =
      Field('personalImageURL', _$personalImageURL);
  static UserRoleEnum _$userRole(TouristGuideRegisterRequest v) => v.userRole;
  static const Field<TouristGuideRegisterRequest, UserRoleEnum> _f$userRole =
      Field('userRole', _$userRole, opt: true, def: UserRoleEnum.touristGuide);
  static String _$addressURL(TouristGuideRegisterRequest v) => v.addressURL;
  static const Field<TouristGuideRegisterRequest, String> _f$addressURL =
      Field('addressURL', _$addressURL);
  static String _$whatsAppPhoneNumber(TouristGuideRegisterRequest v) =>
      v.whatsAppPhoneNumber;
  static const Field<TouristGuideRegisterRequest, String>
      _f$whatsAppPhoneNumber =
      Field('whatsAppPhoneNumber', _$whatsAppPhoneNumber);
  static LocalizedString _$description(TouristGuideRegisterRequest v) =>
      v.description;
  static const Field<TouristGuideRegisterRequest, LocalizedString>
      _f$description = Field('description', _$description);
  static bool? _$approved(TouristGuideRegisterRequest v) => v.approved;
  static const Field<TouristGuideRegisterRequest, bool> _f$approved =
      Field('approved', _$approved, opt: true);

  @override
  final MappableFields<TouristGuideRegisterRequest> fields = const {
    #userId: _f$userId,
    #addressString: _f$addressString,
    #name: _f$name,
    #email: _f$email,
    #password: _f$password,
    #phoneNumber: _f$phoneNumber,
    #personalImageURL: _f$personalImageURL,
    #userRole: _f$userRole,
    #addressURL: _f$addressURL,
    #whatsAppPhoneNumber: _f$whatsAppPhoneNumber,
    #description: _f$description,
    #approved: _f$approved,
  };

  static TouristGuideRegisterRequest _instantiate(DecodingData data) {
    return TouristGuideRegisterRequest(
        userId: data.dec(_f$userId),
        addressString: data.dec(_f$addressString),
        name: data.dec(_f$name),
        email: data.dec(_f$email),
        password: data.dec(_f$password),
        phoneNumber: data.dec(_f$phoneNumber),
        personalImageURL: data.dec(_f$personalImageURL),
        userRole: data.dec(_f$userRole),
        addressURL: data.dec(_f$addressURL),
        whatsAppPhoneNumber: data.dec(_f$whatsAppPhoneNumber),
        description: data.dec(_f$description),
        approved: data.dec(_f$approved));
  }

  @override
  final Function instantiate = _instantiate;

  static TouristGuideRegisterRequest fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<TouristGuideRegisterRequest>(map);
  }

  static TouristGuideRegisterRequest fromJson(String json) {
    return ensureInitialized().decodeJson<TouristGuideRegisterRequest>(json);
  }
}

mixin TouristGuideRegisterRequestMappable {
  String toJson() {
    return TouristGuideRegisterRequestMapper.ensureInitialized()
        .encodeJson<TouristGuideRegisterRequest>(
            this as TouristGuideRegisterRequest);
  }

  Map<String, dynamic> toMap() {
    return TouristGuideRegisterRequestMapper.ensureInitialized()
        .encodeMap<TouristGuideRegisterRequest>(
            this as TouristGuideRegisterRequest);
  }

  TouristGuideRegisterRequestCopyWith<TouristGuideRegisterRequest,
          TouristGuideRegisterRequest, TouristGuideRegisterRequest>
      get copyWith => _TouristGuideRegisterRequestCopyWithImpl(
          this as TouristGuideRegisterRequest, $identity, $identity);
  @override
  String toString() {
    return TouristGuideRegisterRequestMapper.ensureInitialized()
        .stringifyValue(this as TouristGuideRegisterRequest);
  }

  @override
  bool operator ==(Object other) {
    return TouristGuideRegisterRequestMapper.ensureInitialized()
        .equalsValue(this as TouristGuideRegisterRequest, other);
  }

  @override
  int get hashCode {
    return TouristGuideRegisterRequestMapper.ensureInitialized()
        .hashValue(this as TouristGuideRegisterRequest);
  }
}

extension TouristGuideRegisterRequestValueCopy<$R, $Out>
    on ObjectCopyWith<$R, TouristGuideRegisterRequest, $Out> {
  TouristGuideRegisterRequestCopyWith<$R, TouristGuideRegisterRequest, $Out>
      get $asTouristGuideRegisterRequest => $base
          .as((v, t, t2) => _TouristGuideRegisterRequestCopyWithImpl(v, t, t2));
}

abstract class TouristGuideRegisterRequestCopyWith<
    $R,
    $In extends TouristGuideRegisterRequest,
    $Out> implements RegisterRequestCopyWith<$R, $In, $Out> {
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get description;
  @override
  $R call(
      {String? userId,
      String? addressString,
      String? name,
      String? email,
      String? password,
      String? phoneNumber,
      String? personalImageURL,
      UserRoleEnum? userRole,
      String? addressURL,
      String? whatsAppPhoneNumber,
      LocalizedString? description,
      bool? approved});
  TouristGuideRegisterRequestCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(
      Then<$Out2, $R2> t);
}

class _TouristGuideRegisterRequestCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, TouristGuideRegisterRequest, $Out>
    implements
        TouristGuideRegisterRequestCopyWith<$R, TouristGuideRegisterRequest,
            $Out> {
  _TouristGuideRegisterRequestCopyWithImpl(
      super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<TouristGuideRegisterRequest> $mapper =
      TouristGuideRegisterRequestMapper.ensureInitialized();
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>
      get description =>
          $value.description.copyWith.$chain((v) => call(description: v));
  @override
  $R call(
          {String? userId,
          String? addressString,
          String? name,
          String? email,
          String? password,
          String? phoneNumber,
          String? personalImageURL,
          UserRoleEnum? userRole,
          String? addressURL,
          String? whatsAppPhoneNumber,
          LocalizedString? description,
          Object? approved = $none}) =>
      $apply(FieldCopyWithData({
        if (userId != null) #userId: userId,
        if (addressString != null) #addressString: addressString,
        if (name != null) #name: name,
        if (email != null) #email: email,
        if (password != null) #password: password,
        if (phoneNumber != null) #phoneNumber: phoneNumber,
        if (personalImageURL != null) #personalImageURL: personalImageURL,
        if (userRole != null) #userRole: userRole,
        if (addressURL != null) #addressURL: addressURL,
        if (whatsAppPhoneNumber != null)
          #whatsAppPhoneNumber: whatsAppPhoneNumber,
        if (description != null) #description: description,
        if (approved != $none) #approved: approved
      }));
  @override
  TouristGuideRegisterRequest $make(CopyWithData data) =>
      TouristGuideRegisterRequest(
          userId: data.get(#userId, or: $value.userId),
          addressString: data.get(#addressString, or: $value.addressString),
          name: data.get(#name, or: $value.name),
          email: data.get(#email, or: $value.email),
          password: data.get(#password, or: $value.password),
          phoneNumber: data.get(#phoneNumber, or: $value.phoneNumber),
          personalImageURL:
              data.get(#personalImageURL, or: $value.personalImageURL),
          userRole: data.get(#userRole, or: $value.userRole),
          addressURL: data.get(#addressURL, or: $value.addressURL),
          whatsAppPhoneNumber:
              data.get(#whatsAppPhoneNumber, or: $value.whatsAppPhoneNumber),
          description: data.get(#description, or: $value.description),
          approved: data.get(#approved, or: $value.approved));

  @override
  TouristGuideRegisterRequestCopyWith<$R2, TouristGuideRegisterRequest, $Out2>
      $chain<$R2, $Out2>(Then<$Out2, $R2> t) =>
          _TouristGuideRegisterRequestCopyWithImpl($value, $cast, t);
}
