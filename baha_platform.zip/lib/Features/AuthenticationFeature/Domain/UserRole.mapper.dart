// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'UserRole.dart';

class UserRoleEnumMapper extends EnumMapper<UserRoleEnum> {
  UserRoleEnumMapper._();

  static UserRoleEnumMapper? _instance;
  static UserRoleEnumMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = UserRoleEnumMapper._());
    }
    return _instance!;
  }

  static UserRoleEnum fromValue(dynamic value) {
    ensureInitialized();
    return MapperContainer.globals.fromValue(value);
  }

  @override
  UserRoleEnum decode(dynamic value) {
    switch (value) {
      case 'admin':
        return UserRoleEnum.admin;
      case 'customer':
        return UserRoleEnum.customer;
      case 'shop':
        return UserRoleEnum.shop;
      case 'touristGuide':
        return UserRoleEnum.touristGuide;
      default:
        throw MapperException.unknownEnumValue(value);
    }
  }

  @override
  dynamic encode(UserRoleEnum self) {
    switch (self) {
      case UserRoleEnum.admin:
        return 'admin';
      case UserRoleEnum.customer:
        return 'customer';
      case UserRoleEnum.shop:
        return 'shop';
      case UserRoleEnum.touristGuide:
        return 'touristGuide';
    }
  }
}

extension UserRoleEnumMapperExtension on UserRoleEnum {
  String toValue() {
    UserRoleEnumMapper.ensureInitialized();
    return MapperContainer.globals.toValue<UserRoleEnum>(this) as String;
  }
}

class ShopTypeEnumMapper extends EnumMapper<ShopTypeEnum> {
  ShopTypeEnumMapper._();

  static ShopTypeEnumMapper? _instance;
  static ShopTypeEnumMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = ShopTypeEnumMapper._());
    }
    return _instance!;
  }

  static ShopTypeEnum fromValue(dynamic value) {
    ensureInitialized();
    return MapperContainer.globals.fromValue(value);
  }

  @override
  ShopTypeEnum decode(dynamic value) {
    switch (value) {
      case 'productiveFamilyShop':
        return ShopTypeEnum.productiveFamilyShop;
      case 'agriculturalShop':
        return ShopTypeEnum.agriculturalShop;
      case 'artisanShop':
        return ShopTypeEnum.artisanShop;
      default:
        throw MapperException.unknownEnumValue(value);
    }
  }

  @override
  dynamic encode(ShopTypeEnum self) {
    switch (self) {
      case ShopTypeEnum.productiveFamilyShop:
        return 'productiveFamilyShop';
      case ShopTypeEnum.agriculturalShop:
        return 'agriculturalShop';
      case ShopTypeEnum.artisanShop:
        return 'artisanShop';
    }
  }
}

extension ShopTypeEnumMapperExtension on ShopTypeEnum {
  String toValue() {
    ShopTypeEnumMapper.ensureInitialized();
    return MapperContainer.globals.toValue<ShopTypeEnum>(this) as String;
  }
}

class UserRoleMapper extends ClassMapperBase<UserRole> {
  UserRoleMapper._();

  static UserRoleMapper? _instance;
  static UserRoleMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = UserRoleMapper._());
      AdminMapper.ensureInitialized();
      CustomerMapper.ensureInitialized();
      ShopMapper.ensureInitialized();
      TouristGuideMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'UserRole';

  static User? _$user(UserRole v) => v.user;
  static const Field<UserRole, User> _f$user = Field('user', _$user, opt: true);
  static String _$personalImageURL(UserRole v) => v.personalImageURL;
  static const Field<UserRole, String> _f$personalImageURL =
      Field('personalImageURL', _$personalImageURL);
  static String _$addressString(UserRole v) => v.addressString;
  static const Field<UserRole, String> _f$addressString =
      Field('addressString', _$addressString);
  static String _$phoneNumber(UserRole v) => v.phoneNumber;
  static const Field<UserRole, String> _f$phoneNumber =
      Field('phoneNumber', _$phoneNumber);
  static String _$name(UserRole v) => v.name;
  static const Field<UserRole, String> _f$name = Field('name', _$name);
  static String _$email(UserRole v) => v.email;
  static const Field<UserRole, String> _f$email = Field('email', _$email);
  static String _$password(UserRole v) => v.password;
  static const Field<UserRole, String> _f$password =
      Field('password', _$password);

  @override
  final MappableFields<UserRole> fields = const {
    #user: _f$user,
    #personalImageURL: _f$personalImageURL,
    #addressString: _f$addressString,
    #phoneNumber: _f$phoneNumber,
    #name: _f$name,
    #email: _f$email,
    #password: _f$password,
  };

  static UserRole _instantiate(DecodingData data) {
    throw MapperException.missingConstructor('UserRole');
  }

  @override
  final Function instantiate = _instantiate;

  static UserRole fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<UserRole>(map);
  }

  static UserRole fromJson(String json) {
    return ensureInitialized().decodeJson<UserRole>(json);
  }
}

mixin UserRoleMappable {
  String toJson();
  Map<String, dynamic> toMap();
  UserRoleCopyWith<UserRole, UserRole, UserRole> get copyWith;
}

abstract class UserRoleCopyWith<$R, $In extends UserRole, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  $R call(
      {User? user,
      String? personalImageURL,
      String? addressString,
      String? phoneNumber,
      String? name,
      String? email,
      String? password});
  UserRoleCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class AdminMapper extends ClassMapperBase<Admin> {
  AdminMapper._();

  static AdminMapper? _instance;
  static AdminMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = AdminMapper._());
      UserRoleMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'Admin';

  static User? _$user(Admin v) => v.user;
  static const Field<Admin, User> _f$user = Field('user', _$user, opt: true);
  static String _$personalImageURL(Admin v) => v.personalImageURL;
  static const Field<Admin, String> _f$personalImageURL =
      Field('personalImageURL', _$personalImageURL);
  static String _$addressString(Admin v) => v.addressString;
  static const Field<Admin, String> _f$addressString =
      Field('addressString', _$addressString);
  static String _$phoneNumber(Admin v) => v.phoneNumber;
  static const Field<Admin, String> _f$phoneNumber =
      Field('phoneNumber', _$phoneNumber);
  static String _$name(Admin v) => v.name;
  static const Field<Admin, String> _f$name = Field('name', _$name);
  static String _$email(Admin v) => v.email;
  static const Field<Admin, String> _f$email = Field('email', _$email);
  static String _$password(Admin v) => v.password;
  static const Field<Admin, String> _f$password = Field('password', _$password);

  @override
  final MappableFields<Admin> fields = const {
    #user: _f$user,
    #personalImageURL: _f$personalImageURL,
    #addressString: _f$addressString,
    #phoneNumber: _f$phoneNumber,
    #name: _f$name,
    #email: _f$email,
    #password: _f$password,
  };

  static Admin _instantiate(DecodingData data) {
    return Admin(
        user: data.dec(_f$user),
        personalImageURL: data.dec(_f$personalImageURL),
        addressString: data.dec(_f$addressString),
        phoneNumber: data.dec(_f$phoneNumber),
        name: data.dec(_f$name),
        email: data.dec(_f$email),
        password: data.dec(_f$password));
  }

  @override
  final Function instantiate = _instantiate;

  static Admin fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<Admin>(map);
  }

  static Admin fromJson(String json) {
    return ensureInitialized().decodeJson<Admin>(json);
  }
}

mixin AdminMappable {
  String toJson() {
    return AdminMapper.ensureInitialized().encodeJson<Admin>(this as Admin);
  }

  Map<String, dynamic> toMap() {
    return AdminMapper.ensureInitialized().encodeMap<Admin>(this as Admin);
  }

  AdminCopyWith<Admin, Admin, Admin> get copyWith =>
      _AdminCopyWithImpl(this as Admin, $identity, $identity);
  @override
  String toString() {
    return AdminMapper.ensureInitialized().stringifyValue(this as Admin);
  }

  @override
  bool operator ==(Object other) {
    return AdminMapper.ensureInitialized().equalsValue(this as Admin, other);
  }

  @override
  int get hashCode {
    return AdminMapper.ensureInitialized().hashValue(this as Admin);
  }
}

extension AdminValueCopy<$R, $Out> on ObjectCopyWith<$R, Admin, $Out> {
  AdminCopyWith<$R, Admin, $Out> get $asAdmin =>
      $base.as((v, t, t2) => _AdminCopyWithImpl(v, t, t2));
}

abstract class AdminCopyWith<$R, $In extends Admin, $Out>
    implements UserRoleCopyWith<$R, $In, $Out> {
  @override
  $R call(
      {User? user,
      String? personalImageURL,
      String? addressString,
      String? phoneNumber,
      String? name,
      String? email,
      String? password});
  AdminCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _AdminCopyWithImpl<$R, $Out> extends ClassCopyWithBase<$R, Admin, $Out>
    implements AdminCopyWith<$R, Admin, $Out> {
  _AdminCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<Admin> $mapper = AdminMapper.ensureInitialized();
  @override
  $R call(
          {Object? user = $none,
          String? personalImageURL,
          String? addressString,
          String? phoneNumber,
          String? name,
          String? email,
          String? password}) =>
      $apply(FieldCopyWithData({
        if (user != $none) #user: user,
        if (personalImageURL != null) #personalImageURL: personalImageURL,
        if (addressString != null) #addressString: addressString,
        if (phoneNumber != null) #phoneNumber: phoneNumber,
        if (name != null) #name: name,
        if (email != null) #email: email,
        if (password != null) #password: password
      }));
  @override
  Admin $make(CopyWithData data) => Admin(
      user: data.get(#user, or: $value.user),
      personalImageURL:
          data.get(#personalImageURL, or: $value.personalImageURL),
      addressString: data.get(#addressString, or: $value.addressString),
      phoneNumber: data.get(#phoneNumber, or: $value.phoneNumber),
      name: data.get(#name, or: $value.name),
      email: data.get(#email, or: $value.email),
      password: data.get(#password, or: $value.password));

  @override
  AdminCopyWith<$R2, Admin, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t) =>
      _AdminCopyWithImpl($value, $cast, t);
}

class CustomerMapper extends ClassMapperBase<Customer> {
  CustomerMapper._();

  static CustomerMapper? _instance;
  static CustomerMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = CustomerMapper._());
      UserRoleMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'Customer';

  static User? _$user(Customer v) => v.user;
  static const Field<Customer, User> _f$user = Field('user', _$user, opt: true);
  static String _$personalImageURL(Customer v) => v.personalImageURL;
  static const Field<Customer, String> _f$personalImageURL =
      Field('personalImageURL', _$personalImageURL);
  static String _$name(Customer v) => v.name;
  static const Field<Customer, String> _f$name = Field('name', _$name);
  static String _$email(Customer v) => v.email;
  static const Field<Customer, String> _f$email = Field('email', _$email);
  static String _$password(Customer v) => v.password;
  static const Field<Customer, String> _f$password =
      Field('password', _$password);
  static String _$addressString(Customer v) => v.addressString;
  static const Field<Customer, String> _f$addressString =
      Field('addressString', _$addressString);
  static String _$phoneNumber(Customer v) => v.phoneNumber;
  static const Field<Customer, String> _f$phoneNumber =
      Field('phoneNumber', _$phoneNumber);

  @override
  final MappableFields<Customer> fields = const {
    #user: _f$user,
    #personalImageURL: _f$personalImageURL,
    #name: _f$name,
    #email: _f$email,
    #password: _f$password,
    #addressString: _f$addressString,
    #phoneNumber: _f$phoneNumber,
  };

  static Customer _instantiate(DecodingData data) {
    return Customer(
        user: data.dec(_f$user),
        personalImageURL: data.dec(_f$personalImageURL),
        name: data.dec(_f$name),
        email: data.dec(_f$email),
        password: data.dec(_f$password),
        addressString: data.dec(_f$addressString),
        phoneNumber: data.dec(_f$phoneNumber));
  }

  @override
  final Function instantiate = _instantiate;

  static Customer fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<Customer>(map);
  }

  static Customer fromJson(String json) {
    return ensureInitialized().decodeJson<Customer>(json);
  }
}

mixin CustomerMappable {
  String toJson() {
    return CustomerMapper.ensureInitialized()
        .encodeJson<Customer>(this as Customer);
  }

  Map<String, dynamic> toMap() {
    return CustomerMapper.ensureInitialized()
        .encodeMap<Customer>(this as Customer);
  }

  CustomerCopyWith<Customer, Customer, Customer> get copyWith =>
      _CustomerCopyWithImpl(this as Customer, $identity, $identity);
  @override
  String toString() {
    return CustomerMapper.ensureInitialized().stringifyValue(this as Customer);
  }

  @override
  bool operator ==(Object other) {
    return CustomerMapper.ensureInitialized()
        .equalsValue(this as Customer, other);
  }

  @override
  int get hashCode {
    return CustomerMapper.ensureInitialized().hashValue(this as Customer);
  }
}

extension CustomerValueCopy<$R, $Out> on ObjectCopyWith<$R, Customer, $Out> {
  CustomerCopyWith<$R, Customer, $Out> get $asCustomer =>
      $base.as((v, t, t2) => _CustomerCopyWithImpl(v, t, t2));
}

abstract class CustomerCopyWith<$R, $In extends Customer, $Out>
    implements UserRoleCopyWith<$R, $In, $Out> {
  @override
  $R call(
      {User? user,
      String? personalImageURL,
      String? name,
      String? email,
      String? password,
      String? addressString,
      String? phoneNumber});
  CustomerCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _CustomerCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, Customer, $Out>
    implements CustomerCopyWith<$R, Customer, $Out> {
  _CustomerCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<Customer> $mapper =
      CustomerMapper.ensureInitialized();
  @override
  $R call(
          {Object? user = $none,
          String? personalImageURL,
          String? name,
          String? email,
          String? password,
          String? addressString,
          String? phoneNumber}) =>
      $apply(FieldCopyWithData({
        if (user != $none) #user: user,
        if (personalImageURL != null) #personalImageURL: personalImageURL,
        if (name != null) #name: name,
        if (email != null) #email: email,
        if (password != null) #password: password,
        if (addressString != null) #addressString: addressString,
        if (phoneNumber != null) #phoneNumber: phoneNumber
      }));
  @override
  Customer $make(CopyWithData data) => Customer(
      user: data.get(#user, or: $value.user),
      personalImageURL:
          data.get(#personalImageURL, or: $value.personalImageURL),
      name: data.get(#name, or: $value.name),
      email: data.get(#email, or: $value.email),
      password: data.get(#password, or: $value.password),
      addressString: data.get(#addressString, or: $value.addressString),
      phoneNumber: data.get(#phoneNumber, or: $value.phoneNumber));

  @override
  CustomerCopyWith<$R2, Customer, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _CustomerCopyWithImpl($value, $cast, t);
}

class ShopMapper extends ClassMapperBase<Shop> {
  ShopMapper._();

  static ShopMapper? _instance;
  static ShopMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = ShopMapper._());
      UserRoleMapper.ensureInitialized();
      LocalizedStringMapper.ensureInitialized();
      ShopTypeEnumMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'Shop';

  static User? _$user(Shop v) => v.user;
  static const Field<Shop, User> _f$user = Field('user', _$user, opt: true);
  static String _$personalImageURL(Shop v) => v.personalImageURL;
  static const Field<Shop, String> _f$personalImageURL =
      Field('personalImageURL', _$personalImageURL);
  static String _$name(Shop v) => v.name;
  static const Field<Shop, String> _f$name = Field('name', _$name);
  static String _$email(Shop v) => v.email;
  static const Field<Shop, String> _f$email = Field('email', _$email);
  static String _$password(Shop v) => v.password;
  static const Field<Shop, String> _f$password = Field('password', _$password);
  static String _$addressString(Shop v) => v.addressString;
  static const Field<Shop, String> _f$addressString =
      Field('addressString', _$addressString);
  static String _$addressURL(Shop v) => v.addressURL;
  static const Field<Shop, String> _f$addressURL =
      Field('addressURL', _$addressURL);
  static LocalizedString _$description(Shop v) => v.description;
  static const Field<Shop, LocalizedString> _f$description =
      Field('description', _$description);
  static String _$phoneNumber(Shop v) => v.phoneNumber;
  static const Field<Shop, String> _f$phoneNumber =
      Field('phoneNumber', _$phoneNumber);
  static ShopTypeEnum _$shopType(Shop v) => v.shopType;
  static const Field<Shop, ShopTypeEnum> _f$shopType =
      Field('shopType', _$shopType);
  static bool? _$approved(Shop v) => v.approved;
  static const Field<Shop, bool> _f$approved = Field('approved', _$approved);

  @override
  final MappableFields<Shop> fields = const {
    #user: _f$user,
    #personalImageURL: _f$personalImageURL,
    #name: _f$name,
    #email: _f$email,
    #password: _f$password,
    #addressString: _f$addressString,
    #addressURL: _f$addressURL,
    #description: _f$description,
    #phoneNumber: _f$phoneNumber,
    #shopType: _f$shopType,
    #approved: _f$approved,
  };

  static Shop _instantiate(DecodingData data) {
    return Shop(
        user: data.dec(_f$user),
        personalImageURL: data.dec(_f$personalImageURL),
        name: data.dec(_f$name),
        email: data.dec(_f$email),
        password: data.dec(_f$password),
        addressString: data.dec(_f$addressString),
        addressURL: data.dec(_f$addressURL),
        description: data.dec(_f$description),
        phoneNumber: data.dec(_f$phoneNumber),
        shopType: data.dec(_f$shopType),
        approved: data.dec(_f$approved));
  }

  @override
  final Function instantiate = _instantiate;

  static Shop fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<Shop>(map);
  }

  static Shop fromJson(String json) {
    return ensureInitialized().decodeJson<Shop>(json);
  }
}

mixin ShopMappable {
  String toJson() {
    return ShopMapper.ensureInitialized().encodeJson<Shop>(this as Shop);
  }

  Map<String, dynamic> toMap() {
    return ShopMapper.ensureInitialized().encodeMap<Shop>(this as Shop);
  }

  ShopCopyWith<Shop, Shop, Shop> get copyWith =>
      _ShopCopyWithImpl(this as Shop, $identity, $identity);
  @override
  String toString() {
    return ShopMapper.ensureInitialized().stringifyValue(this as Shop);
  }

  @override
  bool operator ==(Object other) {
    return ShopMapper.ensureInitialized().equalsValue(this as Shop, other);
  }

  @override
  int get hashCode {
    return ShopMapper.ensureInitialized().hashValue(this as Shop);
  }
}

extension ShopValueCopy<$R, $Out> on ObjectCopyWith<$R, Shop, $Out> {
  ShopCopyWith<$R, Shop, $Out> get $asShop =>
      $base.as((v, t, t2) => _ShopCopyWithImpl(v, t, t2));
}

abstract class ShopCopyWith<$R, $In extends Shop, $Out>
    implements UserRoleCopyWith<$R, $In, $Out> {
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get description;
  @override
  $R call(
      {User? user,
      String? personalImageURL,
      String? name,
      String? email,
      String? password,
      String? addressString,
      String? addressURL,
      LocalizedString? description,
      String? phoneNumber,
      ShopTypeEnum? shopType,
      bool? approved});
  ShopCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _ShopCopyWithImpl<$R, $Out> extends ClassCopyWithBase<$R, Shop, $Out>
    implements ShopCopyWith<$R, Shop, $Out> {
  _ShopCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<Shop> $mapper = ShopMapper.ensureInitialized();
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>
      get description =>
          $value.description.copyWith.$chain((v) => call(description: v));
  @override
  $R call(
          {Object? user = $none,
          String? personalImageURL,
          String? name,
          String? email,
          String? password,
          String? addressString,
          String? addressURL,
          LocalizedString? description,
          String? phoneNumber,
          ShopTypeEnum? shopType,
          Object? approved = $none}) =>
      $apply(FieldCopyWithData({
        if (user != $none) #user: user,
        if (personalImageURL != null) #personalImageURL: personalImageURL,
        if (name != null) #name: name,
        if (email != null) #email: email,
        if (password != null) #password: password,
        if (addressString != null) #addressString: addressString,
        if (addressURL != null) #addressURL: addressURL,
        if (description != null) #description: description,
        if (phoneNumber != null) #phoneNumber: phoneNumber,
        if (shopType != null) #shopType: shopType,
        if (approved != $none) #approved: approved
      }));
  @override
  Shop $make(CopyWithData data) => Shop(
      user: data.get(#user, or: $value.user),
      personalImageURL:
          data.get(#personalImageURL, or: $value.personalImageURL),
      name: data.get(#name, or: $value.name),
      email: data.get(#email, or: $value.email),
      password: data.get(#password, or: $value.password),
      addressString: data.get(#addressString, or: $value.addressString),
      addressURL: data.get(#addressURL, or: $value.addressURL),
      description: data.get(#description, or: $value.description),
      phoneNumber: data.get(#phoneNumber, or: $value.phoneNumber),
      shopType: data.get(#shopType, or: $value.shopType),
      approved: data.get(#approved, or: $value.approved));

  @override
  ShopCopyWith<$R2, Shop, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t) =>
      _ShopCopyWithImpl($value, $cast, t);
}

class TouristGuideMapper extends ClassMapperBase<TouristGuide> {
  TouristGuideMapper._();

  static TouristGuideMapper? _instance;
  static TouristGuideMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = TouristGuideMapper._());
      UserRoleMapper.ensureInitialized();
      LocalizedStringMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'TouristGuide';

  static User? _$user(TouristGuide v) => v.user;
  static const Field<TouristGuide, User> _f$user =
      Field('user', _$user, opt: true);
  static String _$personalImageURL(TouristGuide v) => v.personalImageURL;
  static const Field<TouristGuide, String> _f$personalImageURL =
      Field('personalImageURL', _$personalImageURL);
  static String _$name(TouristGuide v) => v.name;
  static const Field<TouristGuide, String> _f$name = Field('name', _$name);
  static String _$email(TouristGuide v) => v.email;
  static const Field<TouristGuide, String> _f$email = Field('email', _$email);
  static String _$password(TouristGuide v) => v.password;
  static const Field<TouristGuide, String> _f$password =
      Field('password', _$password);
  static String _$addressString(TouristGuide v) => v.addressString;
  static const Field<TouristGuide, String> _f$addressString =
      Field('addressString', _$addressString);
  static String _$addressURL(TouristGuide v) => v.addressURL;
  static const Field<TouristGuide, String> _f$addressURL =
      Field('addressURL', _$addressURL);
  static LocalizedString _$description(TouristGuide v) => v.description;
  static const Field<TouristGuide, LocalizedString> _f$description =
      Field('description', _$description);
  static String _$phoneNumber(TouristGuide v) => v.phoneNumber;
  static const Field<TouristGuide, String> _f$phoneNumber =
      Field('phoneNumber', _$phoneNumber);
  static String _$additionalPhoneNumber(TouristGuide v) =>
      v.additionalPhoneNumber;
  static const Field<TouristGuide, String> _f$additionalPhoneNumber =
      Field('additionalPhoneNumber', _$additionalPhoneNumber);
  static bool? _$approved(TouristGuide v) => v.approved;
  static const Field<TouristGuide, bool> _f$approved =
      Field('approved', _$approved);

  @override
  final MappableFields<TouristGuide> fields = const {
    #user: _f$user,
    #personalImageURL: _f$personalImageURL,
    #name: _f$name,
    #email: _f$email,
    #password: _f$password,
    #addressString: _f$addressString,
    #addressURL: _f$addressURL,
    #description: _f$description,
    #phoneNumber: _f$phoneNumber,
    #additionalPhoneNumber: _f$additionalPhoneNumber,
    #approved: _f$approved,
  };

  static TouristGuide _instantiate(DecodingData data) {
    return TouristGuide(
        user: data.dec(_f$user),
        personalImageURL: data.dec(_f$personalImageURL),
        name: data.dec(_f$name),
        email: data.dec(_f$email),
        password: data.dec(_f$password),
        addressString: data.dec(_f$addressString),
        addressURL: data.dec(_f$addressURL),
        description: data.dec(_f$description),
        phoneNumber: data.dec(_f$phoneNumber),
        additionalPhoneNumber: data.dec(_f$additionalPhoneNumber),
        approved: data.dec(_f$approved));
  }

  @override
  final Function instantiate = _instantiate;

  static TouristGuide fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<TouristGuide>(map);
  }

  static TouristGuide fromJson(String json) {
    return ensureInitialized().decodeJson<TouristGuide>(json);
  }
}

mixin TouristGuideMappable {
  String toJson() {
    return TouristGuideMapper.ensureInitialized()
        .encodeJson<TouristGuide>(this as TouristGuide);
  }

  Map<String, dynamic> toMap() {
    return TouristGuideMapper.ensureInitialized()
        .encodeMap<TouristGuide>(this as TouristGuide);
  }

  TouristGuideCopyWith<TouristGuide, TouristGuide, TouristGuide> get copyWith =>
      _TouristGuideCopyWithImpl(this as TouristGuide, $identity, $identity);
  @override
  String toString() {
    return TouristGuideMapper.ensureInitialized()
        .stringifyValue(this as TouristGuide);
  }

  @override
  bool operator ==(Object other) {
    return TouristGuideMapper.ensureInitialized()
        .equalsValue(this as TouristGuide, other);
  }

  @override
  int get hashCode {
    return TouristGuideMapper.ensureInitialized()
        .hashValue(this as TouristGuide);
  }
}

extension TouristGuideValueCopy<$R, $Out>
    on ObjectCopyWith<$R, TouristGuide, $Out> {
  TouristGuideCopyWith<$R, TouristGuide, $Out> get $asTouristGuide =>
      $base.as((v, t, t2) => _TouristGuideCopyWithImpl(v, t, t2));
}

abstract class TouristGuideCopyWith<$R, $In extends TouristGuide, $Out>
    implements UserRoleCopyWith<$R, $In, $Out> {
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get description;
  @override
  $R call(
      {User? user,
      String? personalImageURL,
      String? name,
      String? email,
      String? password,
      String? addressString,
      String? addressURL,
      LocalizedString? description,
      String? phoneNumber,
      String? additionalPhoneNumber,
      bool? approved});
  TouristGuideCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _TouristGuideCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, TouristGuide, $Out>
    implements TouristGuideCopyWith<$R, TouristGuide, $Out> {
  _TouristGuideCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<TouristGuide> $mapper =
      TouristGuideMapper.ensureInitialized();
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>
      get description =>
          $value.description.copyWith.$chain((v) => call(description: v));
  @override
  $R call(
          {Object? user = $none,
          String? personalImageURL,
          String? name,
          String? email,
          String? password,
          String? addressString,
          String? addressURL,
          LocalizedString? description,
          String? phoneNumber,
          String? additionalPhoneNumber,
          Object? approved = $none}) =>
      $apply(FieldCopyWithData({
        if (user != $none) #user: user,
        if (personalImageURL != null) #personalImageURL: personalImageURL,
        if (name != null) #name: name,
        if (email != null) #email: email,
        if (password != null) #password: password,
        if (addressString != null) #addressString: addressString,
        if (addressURL != null) #addressURL: addressURL,
        if (description != null) #description: description,
        if (phoneNumber != null) #phoneNumber: phoneNumber,
        if (additionalPhoneNumber != null)
          #additionalPhoneNumber: additionalPhoneNumber,
        if (approved != $none) #approved: approved
      }));
  @override
  TouristGuide $make(CopyWithData data) => TouristGuide(
      user: data.get(#user, or: $value.user),
      personalImageURL:
          data.get(#personalImageURL, or: $value.personalImageURL),
      name: data.get(#name, or: $value.name),
      email: data.get(#email, or: $value.email),
      password: data.get(#password, or: $value.password),
      addressString: data.get(#addressString, or: $value.addressString),
      addressURL: data.get(#addressURL, or: $value.addressURL),
      description: data.get(#description, or: $value.description),
      phoneNumber: data.get(#phoneNumber, or: $value.phoneNumber),
      additionalPhoneNumber:
          data.get(#additionalPhoneNumber, or: $value.additionalPhoneNumber),
      approved: data.get(#approved, or: $value.approved));

  @override
  TouristGuideCopyWith<$R2, TouristGuide, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _TouristGuideCopyWithImpl($value, $cast, t);
}
