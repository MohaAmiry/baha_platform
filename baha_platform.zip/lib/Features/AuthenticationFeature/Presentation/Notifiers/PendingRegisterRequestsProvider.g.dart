// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'PendingRegisterRequestsProvider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$pendingRegisterRequestsNotifierHash() =>
    r'334a7a8ec5bdc2d1bf5e49183a314b298214c62e';

/// See also [PendingRegisterRequestsNotifier].
@ProviderFor(PendingRegisterRequestsNotifier)
final pendingRegisterRequestsNotifierProvider =
    AutoDisposeStreamNotifierProvider<PendingRegisterRequestsNotifier,
        List<UserResponseDTO>>.internal(
  PendingRegisterRequestsNotifier.new,
  name: r'pendingRegisterRequestsNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$pendingRegisterRequestsNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$PendingRegisterRequestsNotifier
    = AutoDisposeStreamNotifier<List<UserResponseDTO>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
