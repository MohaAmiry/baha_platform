// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'StoriesNotifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$contentStoriesHash() => r'de9cb24c6ba70c17d94b4e4ca61aa458b273d33b';

/// See also [contentStories].
@ProviderFor(contentStories)
final contentStoriesProvider =
    AutoDisposeStreamProvider<List<ContentStories>>.internal(
  contentStories,
  name: r'contentStoriesProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$contentStoriesHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef ContentStoriesRef = AutoDisposeStreamProviderRef<List<ContentStories>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
