// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'ContentStories.dart';

class ContentStoriesDTOMapper extends ClassMapperBase<ContentStoriesDTO> {
  ContentStoriesDTOMapper._();

  static ContentStoriesDTOMapper? _instance;
  static ContentStoriesDTOMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = ContentStoriesDTOMapper._());
      MapperContainer.globals.useAll([TimestampMapper()]);
      StoryDTOMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'ContentStoriesDTO';

  static String _$contentId(ContentStoriesDTO v) => v.contentId;
  static const Field<ContentStoriesDTO, String> _f$contentId =
      Field('contentId', _$contentId);
  static List<StoryDTO> _$stories(ContentStoriesDTO v) => v.stories;
  static const Field<ContentStoriesDTO, List<StoryDTO>> _f$stories =
      Field('stories', _$stories);
  static Timestamp _$latestStoryDate(ContentStoriesDTO v) => v.latestStoryDate;
  static const Field<ContentStoriesDTO, Timestamp> _f$latestStoryDate =
      Field('latestStoryDate', _$latestStoryDate);

  @override
  final MappableFields<ContentStoriesDTO> fields = const {
    #contentId: _f$contentId,
    #stories: _f$stories,
    #latestStoryDate: _f$latestStoryDate,
  };

  static ContentStoriesDTO _instantiate(DecodingData data) {
    return ContentStoriesDTO(
        contentId: data.dec(_f$contentId),
        stories: data.dec(_f$stories),
        latestStoryDate: data.dec(_f$latestStoryDate));
  }

  @override
  final Function instantiate = _instantiate;

  static ContentStoriesDTO fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<ContentStoriesDTO>(map);
  }

  static ContentStoriesDTO fromJson(String json) {
    return ensureInitialized().decodeJson<ContentStoriesDTO>(json);
  }
}

mixin ContentStoriesDTOMappable {
  String toJson() {
    return ContentStoriesDTOMapper.ensureInitialized()
        .encodeJson<ContentStoriesDTO>(this as ContentStoriesDTO);
  }

  Map<String, dynamic> toMap() {
    return ContentStoriesDTOMapper.ensureInitialized()
        .encodeMap<ContentStoriesDTO>(this as ContentStoriesDTO);
  }

  ContentStoriesDTOCopyWith<ContentStoriesDTO, ContentStoriesDTO,
          ContentStoriesDTO>
      get copyWith => _ContentStoriesDTOCopyWithImpl(
          this as ContentStoriesDTO, $identity, $identity);
  @override
  String toString() {
    return ContentStoriesDTOMapper.ensureInitialized()
        .stringifyValue(this as ContentStoriesDTO);
  }

  @override
  bool operator ==(Object other) {
    return ContentStoriesDTOMapper.ensureInitialized()
        .equalsValue(this as ContentStoriesDTO, other);
  }

  @override
  int get hashCode {
    return ContentStoriesDTOMapper.ensureInitialized()
        .hashValue(this as ContentStoriesDTO);
  }
}

extension ContentStoriesDTOValueCopy<$R, $Out>
    on ObjectCopyWith<$R, ContentStoriesDTO, $Out> {
  ContentStoriesDTOCopyWith<$R, ContentStoriesDTO, $Out>
      get $asContentStoriesDTO =>
          $base.as((v, t, t2) => _ContentStoriesDTOCopyWithImpl(v, t, t2));
}

abstract class ContentStoriesDTOCopyWith<$R, $In extends ContentStoriesDTO,
    $Out> implements ClassCopyWith<$R, $In, $Out> {
  ListCopyWith<$R, StoryDTO, StoryDTOCopyWith<$R, StoryDTO, StoryDTO>>
      get stories;
  $R call(
      {String? contentId, List<StoryDTO>? stories, Timestamp? latestStoryDate});
  ContentStoriesDTOCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(
      Then<$Out2, $R2> t);
}

class _ContentStoriesDTOCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, ContentStoriesDTO, $Out>
    implements ContentStoriesDTOCopyWith<$R, ContentStoriesDTO, $Out> {
  _ContentStoriesDTOCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<ContentStoriesDTO> $mapper =
      ContentStoriesDTOMapper.ensureInitialized();
  @override
  ListCopyWith<$R, StoryDTO, StoryDTOCopyWith<$R, StoryDTO, StoryDTO>>
      get stories => ListCopyWith($value.stories,
          (v, t) => v.copyWith.$chain(t), (v) => call(stories: v));
  @override
  $R call(
          {String? contentId,
          List<StoryDTO>? stories,
          Timestamp? latestStoryDate}) =>
      $apply(FieldCopyWithData({
        if (contentId != null) #contentId: contentId,
        if (stories != null) #stories: stories,
        if (latestStoryDate != null) #latestStoryDate: latestStoryDate
      }));
  @override
  ContentStoriesDTO $make(CopyWithData data) => ContentStoriesDTO(
      contentId: data.get(#contentId, or: $value.contentId),
      stories: data.get(#stories, or: $value.stories),
      latestStoryDate: data.get(#latestStoryDate, or: $value.latestStoryDate));

  @override
  ContentStoriesDTOCopyWith<$R2, ContentStoriesDTO, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _ContentStoriesDTOCopyWithImpl($value, $cast, t);
}

class ContentStoriesMapper extends ClassMapperBase<ContentStories> {
  ContentStoriesMapper._();

  static ContentStoriesMapper? _instance;
  static ContentStoriesMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = ContentStoriesMapper._());
      LocalizedStringMapper.ensureInitialized();
      ContentTypeMapper.ensureInitialized();
      StoryMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'ContentStories';

  static String _$contentId(ContentStories v) => v.contentId;
  static const Field<ContentStories, String> _f$contentId =
      Field('contentId', _$contentId);
  static LocalizedString _$area(ContentStories v) => v.area;
  static const Field<ContentStories, LocalizedString> _f$area =
      Field('area', _$area);
  static LocalizedString _$contentTitle(ContentStories v) => v.contentTitle;
  static const Field<ContentStories, LocalizedString> _f$contentTitle =
      Field('contentTitle', _$contentTitle);
  static ContentType _$contentType(ContentStories v) => v.contentType;
  static const Field<ContentStories, ContentType> _f$contentType =
      Field('contentType', _$contentType);
  static String _$previewImageURL(ContentStories v) => v.previewImageURL;
  static const Field<ContentStories, String> _f$previewImageURL =
      Field('previewImageURL', _$previewImageURL);
  static List<Story> _$stories(ContentStories v) => v.stories;
  static const Field<ContentStories, List<Story>> _f$stories =
      Field('stories', _$stories);

  @override
  final MappableFields<ContentStories> fields = const {
    #contentId: _f$contentId,
    #area: _f$area,
    #contentTitle: _f$contentTitle,
    #contentType: _f$contentType,
    #previewImageURL: _f$previewImageURL,
    #stories: _f$stories,
  };

  static ContentStories _instantiate(DecodingData data) {
    return ContentStories(
        contentId: data.dec(_f$contentId),
        area: data.dec(_f$area),
        contentTitle: data.dec(_f$contentTitle),
        contentType: data.dec(_f$contentType),
        previewImageURL: data.dec(_f$previewImageURL),
        stories: data.dec(_f$stories));
  }

  @override
  final Function instantiate = _instantiate;

  static ContentStories fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<ContentStories>(map);
  }

  static ContentStories fromJson(String json) {
    return ensureInitialized().decodeJson<ContentStories>(json);
  }
}

mixin ContentStoriesMappable {
  String toJson() {
    return ContentStoriesMapper.ensureInitialized()
        .encodeJson<ContentStories>(this as ContentStories);
  }

  Map<String, dynamic> toMap() {
    return ContentStoriesMapper.ensureInitialized()
        .encodeMap<ContentStories>(this as ContentStories);
  }

  ContentStoriesCopyWith<ContentStories, ContentStories, ContentStories>
      get copyWith => _ContentStoriesCopyWithImpl(
          this as ContentStories, $identity, $identity);
  @override
  String toString() {
    return ContentStoriesMapper.ensureInitialized()
        .stringifyValue(this as ContentStories);
  }

  @override
  bool operator ==(Object other) {
    return ContentStoriesMapper.ensureInitialized()
        .equalsValue(this as ContentStories, other);
  }

  @override
  int get hashCode {
    return ContentStoriesMapper.ensureInitialized()
        .hashValue(this as ContentStories);
  }
}

extension ContentStoriesValueCopy<$R, $Out>
    on ObjectCopyWith<$R, ContentStories, $Out> {
  ContentStoriesCopyWith<$R, ContentStories, $Out> get $asContentStories =>
      $base.as((v, t, t2) => _ContentStoriesCopyWithImpl(v, t, t2));
}

abstract class ContentStoriesCopyWith<$R, $In extends ContentStories, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get area;
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>
      get contentTitle;
  ListCopyWith<$R, Story, StoryCopyWith<$R, Story, Story>> get stories;
  $R call(
      {String? contentId,
      LocalizedString? area,
      LocalizedString? contentTitle,
      ContentType? contentType,
      String? previewImageURL,
      List<Story>? stories});
  ContentStoriesCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(
      Then<$Out2, $R2> t);
}

class _ContentStoriesCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, ContentStories, $Out>
    implements ContentStoriesCopyWith<$R, ContentStories, $Out> {
  _ContentStoriesCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<ContentStories> $mapper =
      ContentStoriesMapper.ensureInitialized();
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get area =>
      $value.area.copyWith.$chain((v) => call(area: v));
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>
      get contentTitle =>
          $value.contentTitle.copyWith.$chain((v) => call(contentTitle: v));
  @override
  ListCopyWith<$R, Story, StoryCopyWith<$R, Story, Story>> get stories =>
      ListCopyWith($value.stories, (v, t) => v.copyWith.$chain(t),
          (v) => call(stories: v));
  @override
  $R call(
          {String? contentId,
          LocalizedString? area,
          LocalizedString? contentTitle,
          ContentType? contentType,
          String? previewImageURL,
          List<Story>? stories}) =>
      $apply(FieldCopyWithData({
        if (contentId != null) #contentId: contentId,
        if (area != null) #area: area,
        if (contentTitle != null) #contentTitle: contentTitle,
        if (contentType != null) #contentType: contentType,
        if (previewImageURL != null) #previewImageURL: previewImageURL,
        if (stories != null) #stories: stories
      }));
  @override
  ContentStories $make(CopyWithData data) => ContentStories(
      contentId: data.get(#contentId, or: $value.contentId),
      area: data.get(#area, or: $value.area),
      contentTitle: data.get(#contentTitle, or: $value.contentTitle),
      contentType: data.get(#contentType, or: $value.contentType),
      previewImageURL: data.get(#previewImageURL, or: $value.previewImageURL),
      stories: data.get(#stories, or: $value.stories));

  @override
  ContentStoriesCopyWith<$R2, ContentStories, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _ContentStoriesCopyWithImpl($value, $cast, t);
}
