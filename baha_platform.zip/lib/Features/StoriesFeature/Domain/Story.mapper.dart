// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'Story.dart';

class StoryDTOMapper extends ClassMapperBase<StoryDTO> {
  StoryDTOMapper._();

  static StoryDTOMapper? _instance;
  static StoryDTOMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = StoryDTOMapper._());
    }
    return _instance!;
  }

  @override
  final String id = 'StoryDTO';

  static String _$storyId(StoryDTO v) => v.storyId;
  static const Field<StoryDTO, String> _f$storyId = Field('storyId', _$storyId);
  static String _$userId(StoryDTO v) => v.userId;
  static const Field<StoryDTO, String> _f$userId = Field('userId', _$userId);
  static String _$storyURL(StoryDTO v) => v.storyURL;
  static const Field<StoryDTO, String> _f$storyURL =
      Field('storyURL', _$storyURL);
  static bool _$isVideo(StoryDTO v) => v.isVideo;
  static const Field<StoryDTO, bool> _f$isVideo = Field('isVideo', _$isVideo);
  static Timestamp _$recordDate(StoryDTO v) => v.recordDate;
  static const Field<StoryDTO, Timestamp> _f$recordDate =
      Field('recordDate', _$recordDate);

  @override
  final MappableFields<StoryDTO> fields = const {
    #storyId: _f$storyId,
    #userId: _f$userId,
    #storyURL: _f$storyURL,
    #isVideo: _f$isVideo,
    #recordDate: _f$recordDate,
  };

  static StoryDTO _instantiate(DecodingData data) {
    return StoryDTO(
        storyId: data.dec(_f$storyId),
        userId: data.dec(_f$userId),
        storyURL: data.dec(_f$storyURL),
        isVideo: data.dec(_f$isVideo),
        recordDate: data.dec(_f$recordDate));
  }

  @override
  final Function instantiate = _instantiate;

  static StoryDTO fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<StoryDTO>(map);
  }

  static StoryDTO fromJson(String json) {
    return ensureInitialized().decodeJson<StoryDTO>(json);
  }
}

mixin StoryDTOMappable {
  String toJson() {
    return StoryDTOMapper.ensureInitialized()
        .encodeJson<StoryDTO>(this as StoryDTO);
  }

  Map<String, dynamic> toMap() {
    return StoryDTOMapper.ensureInitialized()
        .encodeMap<StoryDTO>(this as StoryDTO);
  }

  StoryDTOCopyWith<StoryDTO, StoryDTO, StoryDTO> get copyWith =>
      _StoryDTOCopyWithImpl(this as StoryDTO, $identity, $identity);
  @override
  String toString() {
    return StoryDTOMapper.ensureInitialized().stringifyValue(this as StoryDTO);
  }

  @override
  bool operator ==(Object other) {
    return StoryDTOMapper.ensureInitialized()
        .equalsValue(this as StoryDTO, other);
  }

  @override
  int get hashCode {
    return StoryDTOMapper.ensureInitialized().hashValue(this as StoryDTO);
  }
}

extension StoryDTOValueCopy<$R, $Out> on ObjectCopyWith<$R, StoryDTO, $Out> {
  StoryDTOCopyWith<$R, StoryDTO, $Out> get $asStoryDTO =>
      $base.as((v, t, t2) => _StoryDTOCopyWithImpl(v, t, t2));
}

abstract class StoryDTOCopyWith<$R, $In extends StoryDTO, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  $R call(
      {String? storyId,
      String? userId,
      String? storyURL,
      bool? isVideo,
      Timestamp? recordDate});
  StoryDTOCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _StoryDTOCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, StoryDTO, $Out>
    implements StoryDTOCopyWith<$R, StoryDTO, $Out> {
  _StoryDTOCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<StoryDTO> $mapper =
      StoryDTOMapper.ensureInitialized();
  @override
  $R call(
          {String? storyId,
          String? userId,
          String? storyURL,
          bool? isVideo,
          Timestamp? recordDate}) =>
      $apply(FieldCopyWithData({
        if (storyId != null) #storyId: storyId,
        if (userId != null) #userId: userId,
        if (storyURL != null) #storyURL: storyURL,
        if (isVideo != null) #isVideo: isVideo,
        if (recordDate != null) #recordDate: recordDate
      }));
  @override
  StoryDTO $make(CopyWithData data) => StoryDTO(
      storyId: data.get(#storyId, or: $value.storyId),
      userId: data.get(#userId, or: $value.userId),
      storyURL: data.get(#storyURL, or: $value.storyURL),
      isVideo: data.get(#isVideo, or: $value.isVideo),
      recordDate: data.get(#recordDate, or: $value.recordDate));

  @override
  StoryDTOCopyWith<$R2, StoryDTO, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _StoryDTOCopyWithImpl($value, $cast, t);
}

class StoryMapper extends ClassMapperBase<Story> {
  StoryMapper._();

  static StoryMapper? _instance;
  static StoryMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = StoryMapper._());
    }
    return _instance!;
  }

  @override
  final String id = 'Story';

  static String _$storyId(Story v) => v.storyId;
  static const Field<Story, String> _f$storyId = Field('storyId', _$storyId);
  static String _$userName(Story v) => v.userName;
  static const Field<Story, String> _f$userName = Field('userName', _$userName);
  static String _$storyURL(Story v) => v.storyURL;
  static const Field<Story, String> _f$storyURL = Field('storyURL', _$storyURL);
  static bool _$isVideo(Story v) => v.isVideo;
  static const Field<Story, bool> _f$isVideo = Field('isVideo', _$isVideo);
  static DateTime _$recordDate(Story v) => v.recordDate;
  static const Field<Story, DateTime> _f$recordDate =
      Field('recordDate', _$recordDate);

  @override
  final MappableFields<Story> fields = const {
    #storyId: _f$storyId,
    #userName: _f$userName,
    #storyURL: _f$storyURL,
    #isVideo: _f$isVideo,
    #recordDate: _f$recordDate,
  };

  static Story _instantiate(DecodingData data) {
    return Story(
        storyId: data.dec(_f$storyId),
        userName: data.dec(_f$userName),
        storyURL: data.dec(_f$storyURL),
        isVideo: data.dec(_f$isVideo),
        recordDate: data.dec(_f$recordDate));
  }

  @override
  final Function instantiate = _instantiate;

  static Story fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<Story>(map);
  }

  static Story fromJson(String json) {
    return ensureInitialized().decodeJson<Story>(json);
  }
}

mixin StoryMappable {
  String toJson() {
    return StoryMapper.ensureInitialized().encodeJson<Story>(this as Story);
  }

  Map<String, dynamic> toMap() {
    return StoryMapper.ensureInitialized().encodeMap<Story>(this as Story);
  }

  StoryCopyWith<Story, Story, Story> get copyWith =>
      _StoryCopyWithImpl(this as Story, $identity, $identity);
  @override
  String toString() {
    return StoryMapper.ensureInitialized().stringifyValue(this as Story);
  }

  @override
  bool operator ==(Object other) {
    return StoryMapper.ensureInitialized().equalsValue(this as Story, other);
  }

  @override
  int get hashCode {
    return StoryMapper.ensureInitialized().hashValue(this as Story);
  }
}

extension StoryValueCopy<$R, $Out> on ObjectCopyWith<$R, Story, $Out> {
  StoryCopyWith<$R, Story, $Out> get $asStory =>
      $base.as((v, t, t2) => _StoryCopyWithImpl(v, t, t2));
}

abstract class StoryCopyWith<$R, $In extends Story, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  $R call(
      {String? storyId,
      String? userName,
      String? storyURL,
      bool? isVideo,
      DateTime? recordDate});
  StoryCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _StoryCopyWithImpl<$R, $Out> extends ClassCopyWithBase<$R, Story, $Out>
    implements StoryCopyWith<$R, Story, $Out> {
  _StoryCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<Story> $mapper = StoryMapper.ensureInitialized();
  @override
  $R call(
          {String? storyId,
          String? userName,
          String? storyURL,
          bool? isVideo,
          DateTime? recordDate}) =>
      $apply(FieldCopyWithData({
        if (storyId != null) #storyId: storyId,
        if (userName != null) #userName: userName,
        if (storyURL != null) #storyURL: storyURL,
        if (isVideo != null) #isVideo: isVideo,
        if (recordDate != null) #recordDate: recordDate
      }));
  @override
  Story $make(CopyWithData data) => Story(
      storyId: data.get(#storyId, or: $value.storyId),
      userName: data.get(#userName, or: $value.userName),
      storyURL: data.get(#storyURL, or: $value.storyURL),
      isVideo: data.get(#isVideo, or: $value.isVideo),
      recordDate: data.get(#recordDate, or: $value.recordDate));

  @override
  StoryCopyWith<$R2, Story, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t) =>
      _StoryCopyWithImpl($value, $cast, t);
}
