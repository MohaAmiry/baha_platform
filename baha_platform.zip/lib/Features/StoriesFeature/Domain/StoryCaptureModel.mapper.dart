// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'StoryCaptureModel.dart';

class StoryCaptureModelMapper extends ClassMapperBase<StoryCaptureModel> {
  StoryCaptureModelMapper._();

  static StoryCaptureModelMapper? _instance;
  static StoryCaptureModelMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = StoryCaptureModelMapper._());
    }
    return _instance!;
  }

  @override
  final String id = 'StoryCaptureModel';

  static XFile? _$selectedFile(StoryCaptureModel v) => v.selectedFile;
  static const Field<StoryCaptureModel, XFile> _f$selectedFile =
      Field('selectedFile', _$selectedFile, opt: true);
  static VideoPlayerController? _$videoController(StoryCaptureModel v) =>
      v.videoController;
  static const Field<StoryCaptureModel, VideoPlayerController>
      _f$videoController =
      Field('videoController', _$videoController, opt: true);

  @override
  final MappableFields<StoryCaptureModel> fields = const {
    #selectedFile: _f$selectedFile,
    #videoController: _f$videoController,
  };

  static StoryCaptureModel _instantiate(DecodingData data) {
    return StoryCaptureModel(
        selectedFile: data.dec(_f$selectedFile),
        videoController: data.dec(_f$videoController));
  }

  @override
  final Function instantiate = _instantiate;

  static StoryCaptureModel fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<StoryCaptureModel>(map);
  }

  static StoryCaptureModel fromJson(String json) {
    return ensureInitialized().decodeJson<StoryCaptureModel>(json);
  }
}

mixin StoryCaptureModelMappable {
  String toJson() {
    return StoryCaptureModelMapper.ensureInitialized()
        .encodeJson<StoryCaptureModel>(this as StoryCaptureModel);
  }

  Map<String, dynamic> toMap() {
    return StoryCaptureModelMapper.ensureInitialized()
        .encodeMap<StoryCaptureModel>(this as StoryCaptureModel);
  }

  StoryCaptureModelCopyWith<StoryCaptureModel, StoryCaptureModel,
          StoryCaptureModel>
      get copyWith => _StoryCaptureModelCopyWithImpl(
          this as StoryCaptureModel, $identity, $identity);
  @override
  String toString() {
    return StoryCaptureModelMapper.ensureInitialized()
        .stringifyValue(this as StoryCaptureModel);
  }

  @override
  bool operator ==(Object other) {
    return StoryCaptureModelMapper.ensureInitialized()
        .equalsValue(this as StoryCaptureModel, other);
  }

  @override
  int get hashCode {
    return StoryCaptureModelMapper.ensureInitialized()
        .hashValue(this as StoryCaptureModel);
  }
}

extension StoryCaptureModelValueCopy<$R, $Out>
    on ObjectCopyWith<$R, StoryCaptureModel, $Out> {
  StoryCaptureModelCopyWith<$R, StoryCaptureModel, $Out>
      get $asStoryCaptureModel =>
          $base.as((v, t, t2) => _StoryCaptureModelCopyWithImpl(v, t, t2));
}

abstract class StoryCaptureModelCopyWith<$R, $In extends StoryCaptureModel,
    $Out> implements ClassCopyWith<$R, $In, $Out> {
  $R call({XFile? selectedFile, VideoPlayerController? videoController});
  StoryCaptureModelCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(
      Then<$Out2, $R2> t);
}

class _StoryCaptureModelCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, StoryCaptureModel, $Out>
    implements StoryCaptureModelCopyWith<$R, StoryCaptureModel, $Out> {
  _StoryCaptureModelCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<StoryCaptureModel> $mapper =
      StoryCaptureModelMapper.ensureInitialized();
  @override
  $R call({Object? selectedFile = $none, Object? videoController = $none}) =>
      $apply(FieldCopyWithData({
        if (selectedFile != $none) #selectedFile: selectedFile,
        if (videoController != $none) #videoController: videoController
      }));
  @override
  StoryCaptureModel $make(CopyWithData data) => StoryCaptureModel(
      selectedFile: data.get(#selectedFile, or: $value.selectedFile),
      videoController: data.get(#videoController, or: $value.videoController));

  @override
  StoryCaptureModelCopyWith<$R2, StoryCaptureModel, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _StoryCaptureModelCopyWithImpl($value, $cast, t);
}
