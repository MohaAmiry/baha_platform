// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'ContentTime.dart';

class DayMapper extends EnumMapper<Day> {
  DayMapper._();

  static DayMapper? _instance;
  static DayMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = DayMapper._());
    }
    return _instance!;
  }

  static Day fromValue(dynamic value) {
    ensureInitialized();
    return MapperContainer.globals.fromValue(value);
  }

  @override
  Day decode(dynamic value) {
    switch (value) {
      case 'saturday':
        return Day.saturday;
      case 'sunday':
        return Day.sunday;
      case 'monday':
        return Day.monday;
      case 'tuesday':
        return Day.tuesday;
      case 'wednesday':
        return Day.wednesday;
      case 'thursday':
        return Day.thursday;
      case 'friday':
        return Day.friday;
      default:
        throw MapperException.unknownEnumValue(value);
    }
  }

  @override
  dynamic encode(Day self) {
    switch (self) {
      case Day.saturday:
        return 'saturday';
      case Day.sunday:
        return 'sunday';
      case Day.monday:
        return 'monday';
      case Day.tuesday:
        return 'tuesday';
      case Day.wednesday:
        return 'wednesday';
      case Day.thursday:
        return 'thursday';
      case Day.friday:
        return 'friday';
    }
  }
}

extension DayMapperExtension on Day {
  String toValue() {
    DayMapper.ensureInitialized();
    return MapperContainer.globals.toValue<Day>(this) as String;
  }
}

class TimeMapper extends ClassMapperBase<Time> {
  TimeMapper._();

  static TimeMapper? _instance;
  static TimeMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = TimeMapper._());
    }
    return _instance!;
  }

  @override
  final String id = 'Time';

  static int _$hour(Time v) => v.hour;
  static const Field<Time, int> _f$hour = Field('hour', _$hour);
  static int _$minute(Time v) => v.minute;
  static const Field<Time, int> _f$minute = Field('minute', _$minute);

  @override
  final MappableFields<Time> fields = const {
    #hour: _f$hour,
    #minute: _f$minute,
  };

  static Time _instantiate(DecodingData data) {
    return Time(hour: data.dec(_f$hour), minute: data.dec(_f$minute));
  }

  @override
  final Function instantiate = _instantiate;

  static Time fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<Time>(map);
  }

  static Time fromJson(String json) {
    return ensureInitialized().decodeJson<Time>(json);
  }
}

mixin TimeMappable {
  String toJson() {
    return TimeMapper.ensureInitialized().encodeJson<Time>(this as Time);
  }

  Map<String, dynamic> toMap() {
    return TimeMapper.ensureInitialized().encodeMap<Time>(this as Time);
  }

  TimeCopyWith<Time, Time, Time> get copyWith =>
      _TimeCopyWithImpl(this as Time, $identity, $identity);
  @override
  String toString() {
    return TimeMapper.ensureInitialized().stringifyValue(this as Time);
  }

  @override
  bool operator ==(Object other) {
    return TimeMapper.ensureInitialized().equalsValue(this as Time, other);
  }

  @override
  int get hashCode {
    return TimeMapper.ensureInitialized().hashValue(this as Time);
  }
}

extension TimeValueCopy<$R, $Out> on ObjectCopyWith<$R, Time, $Out> {
  TimeCopyWith<$R, Time, $Out> get $asTime =>
      $base.as((v, t, t2) => _TimeCopyWithImpl(v, t, t2));
}

abstract class TimeCopyWith<$R, $In extends Time, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  $R call({int? hour, int? minute});
  TimeCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _TimeCopyWithImpl<$R, $Out> extends ClassCopyWithBase<$R, Time, $Out>
    implements TimeCopyWith<$R, Time, $Out> {
  _TimeCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<Time> $mapper = TimeMapper.ensureInitialized();
  @override
  $R call({int? hour, int? minute}) => $apply(FieldCopyWithData(
      {if (hour != null) #hour: hour, if (minute != null) #minute: minute}));
  @override
  Time $make(CopyWithData data) => Time(
      hour: data.get(#hour, or: $value.hour),
      minute: data.get(#minute, or: $value.minute));

  @override
  TimeCopyWith<$R2, Time, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t) =>
      _TimeCopyWithImpl($value, $cast, t);
}

class ContentDayTimeMapper extends ClassMapperBase<ContentDayTime> {
  ContentDayTimeMapper._();

  static ContentDayTimeMapper? _instance;
  static ContentDayTimeMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = ContentDayTimeMapper._());
      TimeMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'ContentDayTime';

  static Time _$open(ContentDayTime v) => v.open;
  static const Field<ContentDayTime, Time> _f$open = Field('open', _$open);
  static Time _$close(ContentDayTime v) => v.close;
  static const Field<ContentDayTime, Time> _f$close = Field('close', _$close);

  @override
  final MappableFields<ContentDayTime> fields = const {
    #open: _f$open,
    #close: _f$close,
  };

  static ContentDayTime _instantiate(DecodingData data) {
    return ContentDayTime(open: data.dec(_f$open), close: data.dec(_f$close));
  }

  @override
  final Function instantiate = _instantiate;

  static ContentDayTime fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<ContentDayTime>(map);
  }

  static ContentDayTime fromJson(String json) {
    return ensureInitialized().decodeJson<ContentDayTime>(json);
  }
}

mixin ContentDayTimeMappable {
  String toJson() {
    return ContentDayTimeMapper.ensureInitialized()
        .encodeJson<ContentDayTime>(this as ContentDayTime);
  }

  Map<String, dynamic> toMap() {
    return ContentDayTimeMapper.ensureInitialized()
        .encodeMap<ContentDayTime>(this as ContentDayTime);
  }

  ContentDayTimeCopyWith<ContentDayTime, ContentDayTime, ContentDayTime>
      get copyWith => _ContentDayTimeCopyWithImpl(
          this as ContentDayTime, $identity, $identity);
  @override
  String toString() {
    return ContentDayTimeMapper.ensureInitialized()
        .stringifyValue(this as ContentDayTime);
  }

  @override
  bool operator ==(Object other) {
    return ContentDayTimeMapper.ensureInitialized()
        .equalsValue(this as ContentDayTime, other);
  }

  @override
  int get hashCode {
    return ContentDayTimeMapper.ensureInitialized()
        .hashValue(this as ContentDayTime);
  }
}

extension ContentDayTimeValueCopy<$R, $Out>
    on ObjectCopyWith<$R, ContentDayTime, $Out> {
  ContentDayTimeCopyWith<$R, ContentDayTime, $Out> get $asContentDayTime =>
      $base.as((v, t, t2) => _ContentDayTimeCopyWithImpl(v, t, t2));
}

abstract class ContentDayTimeCopyWith<$R, $In extends ContentDayTime, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  TimeCopyWith<$R, Time, Time> get open;
  TimeCopyWith<$R, Time, Time> get close;
  $R call({Time? open, Time? close});
  ContentDayTimeCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(
      Then<$Out2, $R2> t);
}

class _ContentDayTimeCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, ContentDayTime, $Out>
    implements ContentDayTimeCopyWith<$R, ContentDayTime, $Out> {
  _ContentDayTimeCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<ContentDayTime> $mapper =
      ContentDayTimeMapper.ensureInitialized();
  @override
  TimeCopyWith<$R, Time, Time> get open =>
      $value.open.copyWith.$chain((v) => call(open: v));
  @override
  TimeCopyWith<$R, Time, Time> get close =>
      $value.close.copyWith.$chain((v) => call(close: v));
  @override
  $R call({Time? open, Time? close}) => $apply(FieldCopyWithData(
      {if (open != null) #open: open, if (close != null) #close: close}));
  @override
  ContentDayTime $make(CopyWithData data) => ContentDayTime(
      open: data.get(#open, or: $value.open),
      close: data.get(#close, or: $value.close));

  @override
  ContentDayTimeCopyWith<$R2, ContentDayTime, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _ContentDayTimeCopyWithImpl($value, $cast, t);
}

class ContentTimeMapper extends ClassMapperBase<ContentTime> {
  ContentTimeMapper._();

  static ContentTimeMapper? _instance;
  static ContentTimeMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = ContentTimeMapper._());
      ContentDayTimeMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'ContentTime';

  static ContentDayTime? _$saturday(ContentTime v) => v.saturday;
  static const Field<ContentTime, ContentDayTime> _f$saturday =
      Field('saturday', _$saturday, opt: true);
  static ContentDayTime? _$sunday(ContentTime v) => v.sunday;
  static const Field<ContentTime, ContentDayTime> _f$sunday =
      Field('sunday', _$sunday, opt: true);
  static ContentDayTime? _$monday(ContentTime v) => v.monday;
  static const Field<ContentTime, ContentDayTime> _f$monday =
      Field('monday', _$monday, opt: true);
  static ContentDayTime? _$tuesday(ContentTime v) => v.tuesday;
  static const Field<ContentTime, ContentDayTime> _f$tuesday =
      Field('tuesday', _$tuesday, opt: true);
  static ContentDayTime? _$wednesday(ContentTime v) => v.wednesday;
  static const Field<ContentTime, ContentDayTime> _f$wednesday =
      Field('wednesday', _$wednesday, opt: true);
  static ContentDayTime? _$thursday(ContentTime v) => v.thursday;
  static const Field<ContentTime, ContentDayTime> _f$thursday =
      Field('thursday', _$thursday, opt: true);
  static ContentDayTime? _$friday(ContentTime v) => v.friday;
  static const Field<ContentTime, ContentDayTime> _f$friday =
      Field('friday', _$friday, opt: true);

  @override
  final MappableFields<ContentTime> fields = const {
    #saturday: _f$saturday,
    #sunday: _f$sunday,
    #monday: _f$monday,
    #tuesday: _f$tuesday,
    #wednesday: _f$wednesday,
    #thursday: _f$thursday,
    #friday: _f$friday,
  };

  static ContentTime _instantiate(DecodingData data) {
    return ContentTime(
        saturday: data.dec(_f$saturday),
        sunday: data.dec(_f$sunday),
        monday: data.dec(_f$monday),
        tuesday: data.dec(_f$tuesday),
        wednesday: data.dec(_f$wednesday),
        thursday: data.dec(_f$thursday),
        friday: data.dec(_f$friday));
  }

  @override
  final Function instantiate = _instantiate;

  static ContentTime fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<ContentTime>(map);
  }

  static ContentTime fromJson(String json) {
    return ensureInitialized().decodeJson<ContentTime>(json);
  }
}

mixin ContentTimeMappable {
  String toJson() {
    return ContentTimeMapper.ensureInitialized()
        .encodeJson<ContentTime>(this as ContentTime);
  }

  Map<String, dynamic> toMap() {
    return ContentTimeMapper.ensureInitialized()
        .encodeMap<ContentTime>(this as ContentTime);
  }

  ContentTimeCopyWith<ContentTime, ContentTime, ContentTime> get copyWith =>
      _ContentTimeCopyWithImpl(this as ContentTime, $identity, $identity);
  @override
  String toString() {
    return ContentTimeMapper.ensureInitialized()
        .stringifyValue(this as ContentTime);
  }

  @override
  bool operator ==(Object other) {
    return ContentTimeMapper.ensureInitialized()
        .equalsValue(this as ContentTime, other);
  }

  @override
  int get hashCode {
    return ContentTimeMapper.ensureInitialized().hashValue(this as ContentTime);
  }
}

extension ContentTimeValueCopy<$R, $Out>
    on ObjectCopyWith<$R, ContentTime, $Out> {
  ContentTimeCopyWith<$R, ContentTime, $Out> get $asContentTime =>
      $base.as((v, t, t2) => _ContentTimeCopyWithImpl(v, t, t2));
}

abstract class ContentTimeCopyWith<$R, $In extends ContentTime, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  ContentDayTimeCopyWith<$R, ContentDayTime, ContentDayTime>? get saturday;
  ContentDayTimeCopyWith<$R, ContentDayTime, ContentDayTime>? get sunday;
  ContentDayTimeCopyWith<$R, ContentDayTime, ContentDayTime>? get monday;
  ContentDayTimeCopyWith<$R, ContentDayTime, ContentDayTime>? get tuesday;
  ContentDayTimeCopyWith<$R, ContentDayTime, ContentDayTime>? get wednesday;
  ContentDayTimeCopyWith<$R, ContentDayTime, ContentDayTime>? get thursday;
  ContentDayTimeCopyWith<$R, ContentDayTime, ContentDayTime>? get friday;
  $R call(
      {ContentDayTime? saturday,
      ContentDayTime? sunday,
      ContentDayTime? monday,
      ContentDayTime? tuesday,
      ContentDayTime? wednesday,
      ContentDayTime? thursday,
      ContentDayTime? friday});
  ContentTimeCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _ContentTimeCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, ContentTime, $Out>
    implements ContentTimeCopyWith<$R, ContentTime, $Out> {
  _ContentTimeCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<ContentTime> $mapper =
      ContentTimeMapper.ensureInitialized();
  @override
  ContentDayTimeCopyWith<$R, ContentDayTime, ContentDayTime>? get saturday =>
      $value.saturday?.copyWith.$chain((v) => call(saturday: v));
  @override
  ContentDayTimeCopyWith<$R, ContentDayTime, ContentDayTime>? get sunday =>
      $value.sunday?.copyWith.$chain((v) => call(sunday: v));
  @override
  ContentDayTimeCopyWith<$R, ContentDayTime, ContentDayTime>? get monday =>
      $value.monday?.copyWith.$chain((v) => call(monday: v));
  @override
  ContentDayTimeCopyWith<$R, ContentDayTime, ContentDayTime>? get tuesday =>
      $value.tuesday?.copyWith.$chain((v) => call(tuesday: v));
  @override
  ContentDayTimeCopyWith<$R, ContentDayTime, ContentDayTime>? get wednesday =>
      $value.wednesday?.copyWith.$chain((v) => call(wednesday: v));
  @override
  ContentDayTimeCopyWith<$R, ContentDayTime, ContentDayTime>? get thursday =>
      $value.thursday?.copyWith.$chain((v) => call(thursday: v));
  @override
  ContentDayTimeCopyWith<$R, ContentDayTime, ContentDayTime>? get friday =>
      $value.friday?.copyWith.$chain((v) => call(friday: v));
  @override
  $R call(
          {Object? saturday = $none,
          Object? sunday = $none,
          Object? monday = $none,
          Object? tuesday = $none,
          Object? wednesday = $none,
          Object? thursday = $none,
          Object? friday = $none}) =>
      $apply(FieldCopyWithData({
        if (saturday != $none) #saturday: saturday,
        if (sunday != $none) #sunday: sunday,
        if (monday != $none) #monday: monday,
        if (tuesday != $none) #tuesday: tuesday,
        if (wednesday != $none) #wednesday: wednesday,
        if (thursday != $none) #thursday: thursday,
        if (friday != $none) #friday: friday
      }));
  @override
  ContentTime $make(CopyWithData data) => ContentTime(
      saturday: data.get(#saturday, or: $value.saturday),
      sunday: data.get(#sunday, or: $value.sunday),
      monday: data.get(#monday, or: $value.monday),
      tuesday: data.get(#tuesday, or: $value.tuesday),
      wednesday: data.get(#wednesday, or: $value.wednesday),
      thursday: data.get(#thursday, or: $value.thursday),
      friday: data.get(#friday, or: $value.friday));

  @override
  ContentTimeCopyWith<$R2, ContentTime, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _ContentTimeCopyWithImpl($value, $cast, t);
}
