// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'Content.dart';

class ContentDTOMapper extends ClassMapperBase<ContentDTO> {
  ContentDTOMapper._();

  static ContentDTOMapper? _instance;
  static ContentDTOMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = ContentDTOMapper._());
      ContentTypeMapper.ensureInitialized();
      LocalizedStringMapper.ensureInitialized();
      CommentDTOMapper.ensureInitialized();
      ContentTimeMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'ContentDTO';

  static String _$id(ContentDTO v) => v.id;
  static const Field<ContentDTO, String> _f$id = Field('id', _$id);
  static ContentType _$type(ContentDTO v) => v.type;
  static const Field<ContentDTO, ContentType> _f$type = Field('type', _$type);
  static LocalizedString _$title(ContentDTO v) => v.title;
  static const Field<ContentDTO, LocalizedString> _f$title =
      Field('title', _$title);
  static LocalizedString _$description(ContentDTO v) => v.description;
  static const Field<ContentDTO, LocalizedString> _f$description =
      Field('description', _$description);
  static List<String> _$imagesURLs(ContentDTO v) => v.imagesURLs;
  static const Field<ContentDTO, List<String>> _f$imagesURLs =
      Field('imagesURLs', _$imagesURLs);
  static LocalizedString _$area(ContentDTO v) => v.area;
  static const Field<ContentDTO, LocalizedString> _f$area =
      Field('area', _$area);
  static String _$areaURL(ContentDTO v) => v.areaURL;
  static const Field<ContentDTO, String> _f$areaURL =
      Field('areaURL', _$areaURL);
  static List<CommentDTO> _$comments(ContentDTO v) => v.comments;
  static const Field<ContentDTO, List<CommentDTO>> _f$comments =
      Field('comments', _$comments);
  static List<LocalizedString> _$services(ContentDTO v) => v.services;
  static const Field<ContentDTO, List<LocalizedString>> _f$services =
      Field('services', _$services);
  static List<LocalizedString> _$facilities(ContentDTO v) => v.facilities;
  static const Field<ContentDTO, List<LocalizedString>> _f$facilities =
      Field('facilities', _$facilities);
  static ContentTime? _$contentTime(ContentDTO v) => v.contentTime;
  static const Field<ContentDTO, ContentTime> _f$contentTime =
      Field('contentTime', _$contentTime);
  static double? _$distanceFromCenter(ContentDTO v) => v.distanceFromCenter;
  static const Field<ContentDTO, double> _f$distanceFromCenter =
      Field('distanceFromCenter', _$distanceFromCenter);
  static DateTime? _$contentDate(ContentDTO v) => v.contentDate;
  static const Field<ContentDTO, DateTime> _f$contentDate =
      Field('contentDate', _$contentDate);

  @override
  final MappableFields<ContentDTO> fields = const {
    #id: _f$id,
    #type: _f$type,
    #title: _f$title,
    #description: _f$description,
    #imagesURLs: _f$imagesURLs,
    #area: _f$area,
    #areaURL: _f$areaURL,
    #comments: _f$comments,
    #services: _f$services,
    #facilities: _f$facilities,
    #contentTime: _f$contentTime,
    #distanceFromCenter: _f$distanceFromCenter,
    #contentDate: _f$contentDate,
  };

  static ContentDTO _instantiate(DecodingData data) {
    return ContentDTO(
        id: data.dec(_f$id),
        type: data.dec(_f$type),
        title: data.dec(_f$title),
        description: data.dec(_f$description),
        imagesURLs: data.dec(_f$imagesURLs),
        area: data.dec(_f$area),
        areaURL: data.dec(_f$areaURL),
        comments: data.dec(_f$comments),
        services: data.dec(_f$services),
        facilities: data.dec(_f$facilities),
        contentTime: data.dec(_f$contentTime),
        distanceFromCenter: data.dec(_f$distanceFromCenter),
        contentDate: data.dec(_f$contentDate));
  }

  @override
  final Function instantiate = _instantiate;

  static ContentDTO fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<ContentDTO>(map);
  }

  static ContentDTO fromJson(String json) {
    return ensureInitialized().decodeJson<ContentDTO>(json);
  }
}

mixin ContentDTOMappable {
  String toJson() {
    return ContentDTOMapper.ensureInitialized()
        .encodeJson<ContentDTO>(this as ContentDTO);
  }

  Map<String, dynamic> toMap() {
    return ContentDTOMapper.ensureInitialized()
        .encodeMap<ContentDTO>(this as ContentDTO);
  }

  ContentDTOCopyWith<ContentDTO, ContentDTO, ContentDTO> get copyWith =>
      _ContentDTOCopyWithImpl(this as ContentDTO, $identity, $identity);
  @override
  String toString() {
    return ContentDTOMapper.ensureInitialized()
        .stringifyValue(this as ContentDTO);
  }

  @override
  bool operator ==(Object other) {
    return ContentDTOMapper.ensureInitialized()
        .equalsValue(this as ContentDTO, other);
  }

  @override
  int get hashCode {
    return ContentDTOMapper.ensureInitialized().hashValue(this as ContentDTO);
  }
}

extension ContentDTOValueCopy<$R, $Out>
    on ObjectCopyWith<$R, ContentDTO, $Out> {
  ContentDTOCopyWith<$R, ContentDTO, $Out> get $asContentDTO =>
      $base.as((v, t, t2) => _ContentDTOCopyWithImpl(v, t, t2));
}

abstract class ContentDTOCopyWith<$R, $In extends ContentDTO, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get title;
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get description;
  ListCopyWith<$R, String, ObjectCopyWith<$R, String, String>> get imagesURLs;
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get area;
  ListCopyWith<$R, CommentDTO, CommentDTOCopyWith<$R, CommentDTO, CommentDTO>>
      get comments;
  ListCopyWith<$R, LocalizedString,
          LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>>
      get services;
  ListCopyWith<$R, LocalizedString,
          LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>>
      get facilities;
  ContentTimeCopyWith<$R, ContentTime, ContentTime>? get contentTime;
  $R call(
      {String? id,
      ContentType? type,
      LocalizedString? title,
      LocalizedString? description,
      List<String>? imagesURLs,
      LocalizedString? area,
      String? areaURL,
      List<CommentDTO>? comments,
      List<LocalizedString>? services,
      List<LocalizedString>? facilities,
      ContentTime? contentTime,
      double? distanceFromCenter,
      DateTime? contentDate});
  ContentDTOCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _ContentDTOCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, ContentDTO, $Out>
    implements ContentDTOCopyWith<$R, ContentDTO, $Out> {
  _ContentDTOCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<ContentDTO> $mapper =
      ContentDTOMapper.ensureInitialized();
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get title =>
      $value.title.copyWith.$chain((v) => call(title: v));
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>
      get description =>
          $value.description.copyWith.$chain((v) => call(description: v));
  @override
  ListCopyWith<$R, String, ObjectCopyWith<$R, String, String>> get imagesURLs =>
      ListCopyWith($value.imagesURLs, (v, t) => ObjectCopyWith(v, $identity, t),
          (v) => call(imagesURLs: v));
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get area =>
      $value.area.copyWith.$chain((v) => call(area: v));
  @override
  ListCopyWith<$R, CommentDTO, CommentDTOCopyWith<$R, CommentDTO, CommentDTO>>
      get comments => ListCopyWith($value.comments,
          (v, t) => v.copyWith.$chain(t), (v) => call(comments: v));
  @override
  ListCopyWith<$R, LocalizedString,
          LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>>
      get services => ListCopyWith($value.services,
          (v, t) => v.copyWith.$chain(t), (v) => call(services: v));
  @override
  ListCopyWith<$R, LocalizedString,
          LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>>
      get facilities => ListCopyWith($value.facilities,
          (v, t) => v.copyWith.$chain(t), (v) => call(facilities: v));
  @override
  ContentTimeCopyWith<$R, ContentTime, ContentTime>? get contentTime =>
      $value.contentTime?.copyWith.$chain((v) => call(contentTime: v));
  @override
  $R call(
          {String? id,
          ContentType? type,
          LocalizedString? title,
          LocalizedString? description,
          List<String>? imagesURLs,
          LocalizedString? area,
          String? areaURL,
          List<CommentDTO>? comments,
          List<LocalizedString>? services,
          List<LocalizedString>? facilities,
          Object? contentTime = $none,
          Object? distanceFromCenter = $none,
          Object? contentDate = $none}) =>
      $apply(FieldCopyWithData({
        if (id != null) #id: id,
        if (type != null) #type: type,
        if (title != null) #title: title,
        if (description != null) #description: description,
        if (imagesURLs != null) #imagesURLs: imagesURLs,
        if (area != null) #area: area,
        if (areaURL != null) #areaURL: areaURL,
        if (comments != null) #comments: comments,
        if (services != null) #services: services,
        if (facilities != null) #facilities: facilities,
        if (contentTime != $none) #contentTime: contentTime,
        if (distanceFromCenter != $none)
          #distanceFromCenter: distanceFromCenter,
        if (contentDate != $none) #contentDate: contentDate
      }));
  @override
  ContentDTO $make(CopyWithData data) => ContentDTO(
      id: data.get(#id, or: $value.id),
      type: data.get(#type, or: $value.type),
      title: data.get(#title, or: $value.title),
      description: data.get(#description, or: $value.description),
      imagesURLs: data.get(#imagesURLs, or: $value.imagesURLs),
      area: data.get(#area, or: $value.area),
      areaURL: data.get(#areaURL, or: $value.areaURL),
      comments: data.get(#comments, or: $value.comments),
      services: data.get(#services, or: $value.services),
      facilities: data.get(#facilities, or: $value.facilities),
      contentTime: data.get(#contentTime, or: $value.contentTime),
      distanceFromCenter:
          data.get(#distanceFromCenter, or: $value.distanceFromCenter),
      contentDate: data.get(#contentDate, or: $value.contentDate));

  @override
  ContentDTOCopyWith<$R2, ContentDTO, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _ContentDTOCopyWithImpl($value, $cast, t);
}

class ContentMapper extends ClassMapperBase<Content> {
  ContentMapper._();

  static ContentMapper? _instance;
  static ContentMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = ContentMapper._());
      ContentTypeMapper.ensureInitialized();
      LocalizedStringMapper.ensureInitialized();
      CommentMapper.ensureInitialized();
      ContentTimeMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'Content';

  static String _$id(Content v) => v.id;
  static const Field<Content, String> _f$id = Field('id', _$id);
  static ContentType _$type(Content v) => v.type;
  static const Field<Content, ContentType> _f$type = Field('type', _$type);
  static LocalizedString _$title(Content v) => v.title;
  static const Field<Content, LocalizedString> _f$title =
      Field('title', _$title);
  static LocalizedString _$description(Content v) => v.description;
  static const Field<Content, LocalizedString> _f$description =
      Field('description', _$description);
  static List<String> _$imagesURLs(Content v) => v.imagesURLs;
  static const Field<Content, List<String>> _f$imagesURLs =
      Field('imagesURLs', _$imagesURLs);
  static LocalizedString _$area(Content v) => v.area;
  static const Field<Content, LocalizedString> _f$area = Field('area', _$area);
  static String _$areaURL(Content v) => v.areaURL;
  static const Field<Content, String> _f$areaURL = Field('areaURL', _$areaURL);
  static List<Comment> _$comments(Content v) => v.comments;
  static const Field<Content, List<Comment>> _f$comments =
      Field('comments', _$comments);
  static List<LocalizedString> _$services(Content v) => v.services;
  static const Field<Content, List<LocalizedString>> _f$services =
      Field('services', _$services);
  static List<LocalizedString> _$facilities(Content v) => v.facilities;
  static const Field<Content, List<LocalizedString>> _f$facilities =
      Field('facilities', _$facilities);
  static ContentTime? _$contentTime(Content v) => v.contentTime;
  static const Field<Content, ContentTime> _f$contentTime =
      Field('contentTime', _$contentTime, opt: true);
  static double? _$distanceFromCenter(Content v) => v.distanceFromCenter;
  static const Field<Content, double> _f$distanceFromCenter =
      Field('distanceFromCenter', _$distanceFromCenter, opt: true);
  static DateTime? _$contentDate(Content v) => v.contentDate;
  static const Field<Content, DateTime> _f$contentDate =
      Field('contentDate', _$contentDate, opt: true);

  @override
  final MappableFields<Content> fields = const {
    #id: _f$id,
    #type: _f$type,
    #title: _f$title,
    #description: _f$description,
    #imagesURLs: _f$imagesURLs,
    #area: _f$area,
    #areaURL: _f$areaURL,
    #comments: _f$comments,
    #services: _f$services,
    #facilities: _f$facilities,
    #contentTime: _f$contentTime,
    #distanceFromCenter: _f$distanceFromCenter,
    #contentDate: _f$contentDate,
  };

  static Content _instantiate(DecodingData data) {
    return Content(
        id: data.dec(_f$id),
        type: data.dec(_f$type),
        title: data.dec(_f$title),
        description: data.dec(_f$description),
        imagesURLs: data.dec(_f$imagesURLs),
        area: data.dec(_f$area),
        areaURL: data.dec(_f$areaURL),
        comments: data.dec(_f$comments),
        services: data.dec(_f$services),
        facilities: data.dec(_f$facilities),
        contentTime: data.dec(_f$contentTime),
        distanceFromCenter: data.dec(_f$distanceFromCenter),
        contentDate: data.dec(_f$contentDate));
  }

  @override
  final Function instantiate = _instantiate;

  static Content fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<Content>(map);
  }

  static Content fromJson(String json) {
    return ensureInitialized().decodeJson<Content>(json);
  }
}

mixin ContentMappable {
  String toJson() {
    return ContentMapper.ensureInitialized()
        .encodeJson<Content>(this as Content);
  }

  Map<String, dynamic> toMap() {
    return ContentMapper.ensureInitialized()
        .encodeMap<Content>(this as Content);
  }

  ContentCopyWith<Content, Content, Content> get copyWith =>
      _ContentCopyWithImpl(this as Content, $identity, $identity);
  @override
  String toString() {
    return ContentMapper.ensureInitialized().stringifyValue(this as Content);
  }

  @override
  bool operator ==(Object other) {
    return ContentMapper.ensureInitialized()
        .equalsValue(this as Content, other);
  }

  @override
  int get hashCode {
    return ContentMapper.ensureInitialized().hashValue(this as Content);
  }
}

extension ContentValueCopy<$R, $Out> on ObjectCopyWith<$R, Content, $Out> {
  ContentCopyWith<$R, Content, $Out> get $asContent =>
      $base.as((v, t, t2) => _ContentCopyWithImpl(v, t, t2));
}

abstract class ContentCopyWith<$R, $In extends Content, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get title;
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get description;
  ListCopyWith<$R, String, ObjectCopyWith<$R, String, String>> get imagesURLs;
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get area;
  ListCopyWith<$R, Comment, CommentCopyWith<$R, Comment, Comment>> get comments;
  ListCopyWith<$R, LocalizedString,
          LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>>
      get services;
  ListCopyWith<$R, LocalizedString,
          LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>>
      get facilities;
  ContentTimeCopyWith<$R, ContentTime, ContentTime>? get contentTime;
  $R call(
      {String? id,
      ContentType? type,
      LocalizedString? title,
      LocalizedString? description,
      List<String>? imagesURLs,
      LocalizedString? area,
      String? areaURL,
      List<Comment>? comments,
      List<LocalizedString>? services,
      List<LocalizedString>? facilities,
      ContentTime? contentTime,
      double? distanceFromCenter,
      DateTime? contentDate});
  ContentCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _ContentCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, Content, $Out>
    implements ContentCopyWith<$R, Content, $Out> {
  _ContentCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<Content> $mapper =
      ContentMapper.ensureInitialized();
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get title =>
      $value.title.copyWith.$chain((v) => call(title: v));
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>
      get description =>
          $value.description.copyWith.$chain((v) => call(description: v));
  @override
  ListCopyWith<$R, String, ObjectCopyWith<$R, String, String>> get imagesURLs =>
      ListCopyWith($value.imagesURLs, (v, t) => ObjectCopyWith(v, $identity, t),
          (v) => call(imagesURLs: v));
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get area =>
      $value.area.copyWith.$chain((v) => call(area: v));
  @override
  ListCopyWith<$R, Comment, CommentCopyWith<$R, Comment, Comment>>
      get comments => ListCopyWith($value.comments,
          (v, t) => v.copyWith.$chain(t), (v) => call(comments: v));
  @override
  ListCopyWith<$R, LocalizedString,
          LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>>
      get services => ListCopyWith($value.services,
          (v, t) => v.copyWith.$chain(t), (v) => call(services: v));
  @override
  ListCopyWith<$R, LocalizedString,
          LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>>
      get facilities => ListCopyWith($value.facilities,
          (v, t) => v.copyWith.$chain(t), (v) => call(facilities: v));
  @override
  ContentTimeCopyWith<$R, ContentTime, ContentTime>? get contentTime =>
      $value.contentTime?.copyWith.$chain((v) => call(contentTime: v));
  @override
  $R call(
          {String? id,
          ContentType? type,
          LocalizedString? title,
          LocalizedString? description,
          List<String>? imagesURLs,
          LocalizedString? area,
          String? areaURL,
          List<Comment>? comments,
          List<LocalizedString>? services,
          List<LocalizedString>? facilities,
          Object? contentTime = $none,
          Object? distanceFromCenter = $none,
          Object? contentDate = $none}) =>
      $apply(FieldCopyWithData({
        if (id != null) #id: id,
        if (type != null) #type: type,
        if (title != null) #title: title,
        if (description != null) #description: description,
        if (imagesURLs != null) #imagesURLs: imagesURLs,
        if (area != null) #area: area,
        if (areaURL != null) #areaURL: areaURL,
        if (comments != null) #comments: comments,
        if (services != null) #services: services,
        if (facilities != null) #facilities: facilities,
        if (contentTime != $none) #contentTime: contentTime,
        if (distanceFromCenter != $none)
          #distanceFromCenter: distanceFromCenter,
        if (contentDate != $none) #contentDate: contentDate
      }));
  @override
  Content $make(CopyWithData data) => Content(
      id: data.get(#id, or: $value.id),
      type: data.get(#type, or: $value.type),
      title: data.get(#title, or: $value.title),
      description: data.get(#description, or: $value.description),
      imagesURLs: data.get(#imagesURLs, or: $value.imagesURLs),
      area: data.get(#area, or: $value.area),
      areaURL: data.get(#areaURL, or: $value.areaURL),
      comments: data.get(#comments, or: $value.comments),
      services: data.get(#services, or: $value.services),
      facilities: data.get(#facilities, or: $value.facilities),
      contentTime: data.get(#contentTime, or: $value.contentTime),
      distanceFromCenter:
          data.get(#distanceFromCenter, or: $value.distanceFromCenter),
      contentDate: data.get(#contentDate, or: $value.contentDate));

  @override
  ContentCopyWith<$R2, Content, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t) =>
      _ContentCopyWithImpl($value, $cast, t);
}
