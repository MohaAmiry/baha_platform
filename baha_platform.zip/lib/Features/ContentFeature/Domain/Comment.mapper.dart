// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'Comment.dart';

class CommentDTOMapper extends ClassMapperBase<CommentDTO> {
  CommentDTOMapper._();

  static CommentDTOMapper? _instance;
  static CommentDTOMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = CommentDTOMapper._());
    }
    return _instance!;
  }

  @override
  final String id = 'CommentDTO';

  static String _$id(CommentDTO v) => v.id;
  static const Field<CommentDTO, String> _f$id = Field('id', _$id);
  static String _$userId(CommentDTO v) => v.userId;
  static const Field<CommentDTO, String> _f$userId = Field('userId', _$userId);
  static String _$comment(CommentDTO v) => v.comment;
  static const Field<CommentDTO, String> _f$comment =
      Field('comment', _$comment);
  static DateTime _$date(CommentDTO v) => v.date;
  static const Field<CommentDTO, DateTime> _f$date = Field('date', _$date);

  @override
  final MappableFields<CommentDTO> fields = const {
    #id: _f$id,
    #userId: _f$userId,
    #comment: _f$comment,
    #date: _f$date,
  };

  static CommentDTO _instantiate(DecodingData data) {
    return CommentDTO(
        id: data.dec(_f$id),
        userId: data.dec(_f$userId),
        comment: data.dec(_f$comment),
        date: data.dec(_f$date));
  }

  @override
  final Function instantiate = _instantiate;

  static CommentDTO fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<CommentDTO>(map);
  }

  static CommentDTO fromJson(String json) {
    return ensureInitialized().decodeJson<CommentDTO>(json);
  }
}

mixin CommentDTOMappable {
  String toJson() {
    return CommentDTOMapper.ensureInitialized()
        .encodeJson<CommentDTO>(this as CommentDTO);
  }

  Map<String, dynamic> toMap() {
    return CommentDTOMapper.ensureInitialized()
        .encodeMap<CommentDTO>(this as CommentDTO);
  }

  CommentDTOCopyWith<CommentDTO, CommentDTO, CommentDTO> get copyWith =>
      _CommentDTOCopyWithImpl(this as CommentDTO, $identity, $identity);
  @override
  String toString() {
    return CommentDTOMapper.ensureInitialized()
        .stringifyValue(this as CommentDTO);
  }

  @override
  bool operator ==(Object other) {
    return CommentDTOMapper.ensureInitialized()
        .equalsValue(this as CommentDTO, other);
  }

  @override
  int get hashCode {
    return CommentDTOMapper.ensureInitialized().hashValue(this as CommentDTO);
  }
}

extension CommentDTOValueCopy<$R, $Out>
    on ObjectCopyWith<$R, CommentDTO, $Out> {
  CommentDTOCopyWith<$R, CommentDTO, $Out> get $asCommentDTO =>
      $base.as((v, t, t2) => _CommentDTOCopyWithImpl(v, t, t2));
}

abstract class CommentDTOCopyWith<$R, $In extends CommentDTO, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  $R call({String? id, String? userId, String? comment, DateTime? date});
  CommentDTOCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _CommentDTOCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, CommentDTO, $Out>
    implements CommentDTOCopyWith<$R, CommentDTO, $Out> {
  _CommentDTOCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<CommentDTO> $mapper =
      CommentDTOMapper.ensureInitialized();
  @override
  $R call({String? id, String? userId, String? comment, DateTime? date}) =>
      $apply(FieldCopyWithData({
        if (id != null) #id: id,
        if (userId != null) #userId: userId,
        if (comment != null) #comment: comment,
        if (date != null) #date: date
      }));
  @override
  CommentDTO $make(CopyWithData data) => CommentDTO(
      id: data.get(#id, or: $value.id),
      userId: data.get(#userId, or: $value.userId),
      comment: data.get(#comment, or: $value.comment),
      date: data.get(#date, or: $value.date));

  @override
  CommentDTOCopyWith<$R2, CommentDTO, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _CommentDTOCopyWithImpl($value, $cast, t);
}

class CommentMapper extends ClassMapperBase<Comment> {
  CommentMapper._();

  static CommentMapper? _instance;
  static CommentMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = CommentMapper._());
      UserResponseDTOMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'Comment';

  static String _$id(Comment v) => v.id;
  static const Field<Comment, String> _f$id = Field('id', _$id);
  static UserResponseDTO _$userInfo(Comment v) => v.userInfo;
  static const Field<Comment, UserResponseDTO> _f$userInfo =
      Field('userInfo', _$userInfo);
  static String _$comment(Comment v) => v.comment;
  static const Field<Comment, String> _f$comment = Field('comment', _$comment);
  static DateTime _$date(Comment v) => v.date;
  static const Field<Comment, DateTime> _f$date = Field('date', _$date);

  @override
  final MappableFields<Comment> fields = const {
    #id: _f$id,
    #userInfo: _f$userInfo,
    #comment: _f$comment,
    #date: _f$date,
  };

  static Comment _instantiate(DecodingData data) {
    return Comment(
        id: data.dec(_f$id),
        userInfo: data.dec(_f$userInfo),
        comment: data.dec(_f$comment),
        date: data.dec(_f$date));
  }

  @override
  final Function instantiate = _instantiate;

  static Comment fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<Comment>(map);
  }

  static Comment fromJson(String json) {
    return ensureInitialized().decodeJson<Comment>(json);
  }
}

mixin CommentMappable {
  String toJson() {
    return CommentMapper.ensureInitialized()
        .encodeJson<Comment>(this as Comment);
  }

  Map<String, dynamic> toMap() {
    return CommentMapper.ensureInitialized()
        .encodeMap<Comment>(this as Comment);
  }

  CommentCopyWith<Comment, Comment, Comment> get copyWith =>
      _CommentCopyWithImpl(this as Comment, $identity, $identity);
  @override
  String toString() {
    return CommentMapper.ensureInitialized().stringifyValue(this as Comment);
  }

  @override
  bool operator ==(Object other) {
    return CommentMapper.ensureInitialized()
        .equalsValue(this as Comment, other);
  }

  @override
  int get hashCode {
    return CommentMapper.ensureInitialized().hashValue(this as Comment);
  }
}

extension CommentValueCopy<$R, $Out> on ObjectCopyWith<$R, Comment, $Out> {
  CommentCopyWith<$R, Comment, $Out> get $asComment =>
      $base.as((v, t, t2) => _CommentCopyWithImpl(v, t, t2));
}

abstract class CommentCopyWith<$R, $In extends Comment, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  UserResponseDTOCopyWith<$R, UserResponseDTO, UserResponseDTO> get userInfo;
  $R call(
      {String? id, UserResponseDTO? userInfo, String? comment, DateTime? date});
  CommentCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _CommentCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, Comment, $Out>
    implements CommentCopyWith<$R, Comment, $Out> {
  _CommentCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<Comment> $mapper =
      CommentMapper.ensureInitialized();
  @override
  UserResponseDTOCopyWith<$R, UserResponseDTO, UserResponseDTO> get userInfo =>
      $value.userInfo.copyWith.$chain((v) => call(userInfo: v));
  @override
  $R call(
          {String? id,
          UserResponseDTO? userInfo,
          String? comment,
          DateTime? date}) =>
      $apply(FieldCopyWithData({
        if (id != null) #id: id,
        if (userInfo != null) #userInfo: userInfo,
        if (comment != null) #comment: comment,
        if (date != null) #date: date
      }));
  @override
  Comment $make(CopyWithData data) => Comment(
      id: data.get(#id, or: $value.id),
      userInfo: data.get(#userInfo, or: $value.userInfo),
      comment: data.get(#comment, or: $value.comment),
      date: data.get(#date, or: $value.date));

  @override
  CommentCopyWith<$R2, Comment, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t) =>
      _CommentCopyWithImpl($value, $cast, t);
}
