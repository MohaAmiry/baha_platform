// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'ContentPartialData.dart';

class ContentPartialDataMapper extends ClassMapperBase<ContentPartialData> {
  ContentPartialDataMapper._();

  static ContentPartialDataMapper? _instance;
  static ContentPartialDataMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = ContentPartialDataMapper._());
      LocalizedStringMapper.ensureInitialized();
      ContentTypeMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'ContentPartialData';

  static String _$contentId(ContentPartialData v) => v.contentId;
  static const Field<ContentPartialData, String> _f$contentId =
      Field('contentId', _$contentId);
  static LocalizedString _$area(ContentPartialData v) => v.area;
  static const Field<ContentPartialData, LocalizedString> _f$area =
      Field('area', _$area);
  static LocalizedString _$title(ContentPartialData v) => v.title;
  static const Field<ContentPartialData, LocalizedString> _f$title =
      Field('title', _$title);
  static ContentType _$type(ContentPartialData v) => v.type;
  static const Field<ContentPartialData, ContentType> _f$type =
      Field('type', _$type);
  static String _$imagesURLs(ContentPartialData v) => v.imagesURLs;
  static const Field<ContentPartialData, String> _f$imagesURLs =
      Field('imagesURLs', _$imagesURLs);

  @override
  final MappableFields<ContentPartialData> fields = const {
    #contentId: _f$contentId,
    #area: _f$area,
    #title: _f$title,
    #type: _f$type,
    #imagesURLs: _f$imagesURLs,
  };

  static ContentPartialData _instantiate(DecodingData data) {
    return ContentPartialData(
        contentId: data.dec(_f$contentId),
        area: data.dec(_f$area),
        title: data.dec(_f$title),
        type: data.dec(_f$type),
        imagesURLs: data.dec(_f$imagesURLs));
  }

  @override
  final Function instantiate = _instantiate;

  static ContentPartialData fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<ContentPartialData>(map);
  }

  static ContentPartialData fromJson(String json) {
    return ensureInitialized().decodeJson<ContentPartialData>(json);
  }
}

mixin ContentPartialDataMappable {
  String toJson() {
    return ContentPartialDataMapper.ensureInitialized()
        .encodeJson<ContentPartialData>(this as ContentPartialData);
  }

  Map<String, dynamic> toMap() {
    return ContentPartialDataMapper.ensureInitialized()
        .encodeMap<ContentPartialData>(this as ContentPartialData);
  }

  ContentPartialDataCopyWith<ContentPartialData, ContentPartialData,
          ContentPartialData>
      get copyWith => _ContentPartialDataCopyWithImpl(
          this as ContentPartialData, $identity, $identity);
  @override
  String toString() {
    return ContentPartialDataMapper.ensureInitialized()
        .stringifyValue(this as ContentPartialData);
  }

  @override
  bool operator ==(Object other) {
    return ContentPartialDataMapper.ensureInitialized()
        .equalsValue(this as ContentPartialData, other);
  }

  @override
  int get hashCode {
    return ContentPartialDataMapper.ensureInitialized()
        .hashValue(this as ContentPartialData);
  }
}

extension ContentPartialDataValueCopy<$R, $Out>
    on ObjectCopyWith<$R, ContentPartialData, $Out> {
  ContentPartialDataCopyWith<$R, ContentPartialData, $Out>
      get $asContentPartialData =>
          $base.as((v, t, t2) => _ContentPartialDataCopyWithImpl(v, t, t2));
}

abstract class ContentPartialDataCopyWith<$R, $In extends ContentPartialData,
    $Out> implements ClassCopyWith<$R, $In, $Out> {
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get area;
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get title;
  $R call(
      {String? contentId,
      LocalizedString? area,
      LocalizedString? title,
      ContentType? type,
      String? imagesURLs});
  ContentPartialDataCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(
      Then<$Out2, $R2> t);
}

class _ContentPartialDataCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, ContentPartialData, $Out>
    implements ContentPartialDataCopyWith<$R, ContentPartialData, $Out> {
  _ContentPartialDataCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<ContentPartialData> $mapper =
      ContentPartialDataMapper.ensureInitialized();
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get area =>
      $value.area.copyWith.$chain((v) => call(area: v));
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get title =>
      $value.title.copyWith.$chain((v) => call(title: v));
  @override
  $R call(
          {String? contentId,
          LocalizedString? area,
          LocalizedString? title,
          ContentType? type,
          String? imagesURLs}) =>
      $apply(FieldCopyWithData({
        if (contentId != null) #contentId: contentId,
        if (area != null) #area: area,
        if (title != null) #title: title,
        if (type != null) #type: type,
        if (imagesURLs != null) #imagesURLs: imagesURLs
      }));
  @override
  ContentPartialData $make(CopyWithData data) => ContentPartialData(
      contentId: data.get(#contentId, or: $value.contentId),
      area: data.get(#area, or: $value.area),
      title: data.get(#title, or: $value.title),
      type: data.get(#type, or: $value.type),
      imagesURLs: data.get(#imagesURLs, or: $value.imagesURLs));

  @override
  ContentPartialDataCopyWith<$R2, ContentPartialData, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _ContentPartialDataCopyWithImpl($value, $cast, t);
}
