// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'ImagePickerNotifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$imagePickerNotifierHash() =>
    r'8c61b4b76e51df23cf60dd68b5b2f8a211921c81';

/// See also [ImagePickerNotifier].
@ProviderFor(ImagePickerNotifier)
final imagePickerNotifierProvider =
    AutoDisposeNotifierProvider<ImagePickerNotifier, List<XFile>>.internal(
  ImagePickerNotifier.new,
  name: r'imagePickerNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$imagePickerNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$ImagePickerNotifier = AutoDisposeNotifier<List<XFile>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
