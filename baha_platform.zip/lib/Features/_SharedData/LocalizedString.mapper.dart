// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'LocalizedString.dart';

class LocalizedStringMapper extends ClassMapperBase<LocalizedString> {
  LocalizedStringMapper._();

  static LocalizedStringMapper? _instance;
  static LocalizedStringMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = LocalizedStringMapper._());
    }
    return _instance!;
  }

  @override
  final String id = 'LocalizedString';

  static String _$en(LocalizedString v) => v.en;
  static const Field<LocalizedString, String> _f$en = Field('en', _$en);
  static String _$ar(LocalizedString v) => v.ar;
  static const Field<LocalizedString, String> _f$ar = Field('ar', _$ar);

  @override
  final MappableFields<LocalizedString> fields = const {
    #en: _f$en,
    #ar: _f$ar,
  };

  static LocalizedString _instantiate(DecodingData data) {
    return LocalizedString(en: data.dec(_f$en), ar: data.dec(_f$ar));
  }

  @override
  final Function instantiate = _instantiate;

  static LocalizedString fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<LocalizedString>(map);
  }

  static LocalizedString fromJson(String json) {
    return ensureInitialized().decodeJson<LocalizedString>(json);
  }
}

mixin LocalizedStringMappable {
  String toJson() {
    return LocalizedStringMapper.ensureInitialized()
        .encodeJson<LocalizedString>(this as LocalizedString);
  }

  Map<String, dynamic> toMap() {
    return LocalizedStringMapper.ensureInitialized()
        .encodeMap<LocalizedString>(this as LocalizedString);
  }

  LocalizedStringCopyWith<LocalizedString, LocalizedString, LocalizedString>
      get copyWith => _LocalizedStringCopyWithImpl(
          this as LocalizedString, $identity, $identity);
  @override
  String toString() {
    return LocalizedStringMapper.ensureInitialized()
        .stringifyValue(this as LocalizedString);
  }

  @override
  bool operator ==(Object other) {
    return LocalizedStringMapper.ensureInitialized()
        .equalsValue(this as LocalizedString, other);
  }

  @override
  int get hashCode {
    return LocalizedStringMapper.ensureInitialized()
        .hashValue(this as LocalizedString);
  }
}

extension LocalizedStringValueCopy<$R, $Out>
    on ObjectCopyWith<$R, LocalizedString, $Out> {
  LocalizedStringCopyWith<$R, LocalizedString, $Out> get $asLocalizedString =>
      $base.as((v, t, t2) => _LocalizedStringCopyWithImpl(v, t, t2));
}

abstract class LocalizedStringCopyWith<$R, $In extends LocalizedString, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  $R call({String? en, String? ar});
  LocalizedStringCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(
      Then<$Out2, $R2> t);
}

class _LocalizedStringCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, LocalizedString, $Out>
    implements LocalizedStringCopyWith<$R, LocalizedString, $Out> {
  _LocalizedStringCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<LocalizedString> $mapper =
      LocalizedStringMapper.ensureInitialized();
  @override
  $R call({String? en, String? ar}) => $apply(
      FieldCopyWithData({if (en != null) #en: en, if (ar != null) #ar: ar}));
  @override
  LocalizedString $make(CopyWithData data) => LocalizedString(
      en: data.get(#en, or: $value.en), ar: data.get(#ar, or: $value.ar));

  @override
  LocalizedStringCopyWith<$R2, LocalizedString, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _LocalizedStringCopyWithImpl($value, $cast, t);
}
