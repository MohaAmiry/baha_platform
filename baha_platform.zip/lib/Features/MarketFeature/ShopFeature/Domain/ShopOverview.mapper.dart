// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'ShopOverview.dart';

class ShopOverviewMapper extends ClassMapperBase<ShopOverview> {
  ShopOverviewMapper._();

  static ShopOverviewMapper? _instance;
  static ShopOverviewMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = ShopOverviewMapper._());
      ShopTypeEnumMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'ShopOverview';

  static String _$shopId(ShopOverview v) => v.shopId;
  static const Field<ShopOverview, String> _f$shopId =
      Field('shopId', _$shopId);
  static String _$shopName(ShopOverview v) => v.shopName;
  static const Field<ShopOverview, String> _f$shopName =
      Field('shopName', _$shopName);
  static String _$personalImageURL(ShopOverview v) => v.personalImageURL;
  static const Field<ShopOverview, String> _f$personalImageURL =
      Field('personalImageURL', _$personalImageURL);
  static ShopTypeEnum _$shopType(ShopOverview v) => v.shopType;
  static const Field<ShopOverview, ShopTypeEnum> _f$shopType =
      Field('shopType', _$shopType);

  @override
  final MappableFields<ShopOverview> fields = const {
    #shopId: _f$shopId,
    #shopName: _f$shopName,
    #personalImageURL: _f$personalImageURL,
    #shopType: _f$shopType,
  };

  static ShopOverview _instantiate(DecodingData data) {
    return ShopOverview(
        shopId: data.dec(_f$shopId),
        shopName: data.dec(_f$shopName),
        personalImageURL: data.dec(_f$personalImageURL),
        shopType: data.dec(_f$shopType));
  }

  @override
  final Function instantiate = _instantiate;

  static ShopOverview fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<ShopOverview>(map);
  }

  static ShopOverview fromJson(String json) {
    return ensureInitialized().decodeJson<ShopOverview>(json);
  }
}

mixin ShopOverviewMappable {
  String toJson() {
    return ShopOverviewMapper.ensureInitialized()
        .encodeJson<ShopOverview>(this as ShopOverview);
  }

  Map<String, dynamic> toMap() {
    return ShopOverviewMapper.ensureInitialized()
        .encodeMap<ShopOverview>(this as ShopOverview);
  }

  ShopOverviewCopyWith<ShopOverview, ShopOverview, ShopOverview> get copyWith =>
      _ShopOverviewCopyWithImpl(this as ShopOverview, $identity, $identity);
  @override
  String toString() {
    return ShopOverviewMapper.ensureInitialized()
        .stringifyValue(this as ShopOverview);
  }

  @override
  bool operator ==(Object other) {
    return ShopOverviewMapper.ensureInitialized()
        .equalsValue(this as ShopOverview, other);
  }

  @override
  int get hashCode {
    return ShopOverviewMapper.ensureInitialized()
        .hashValue(this as ShopOverview);
  }
}

extension ShopOverviewValueCopy<$R, $Out>
    on ObjectCopyWith<$R, ShopOverview, $Out> {
  ShopOverviewCopyWith<$R, ShopOverview, $Out> get $asShopOverview =>
      $base.as((v, t, t2) => _ShopOverviewCopyWithImpl(v, t, t2));
}

abstract class ShopOverviewCopyWith<$R, $In extends ShopOverview, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  $R call(
      {String? shopId,
      String? shopName,
      String? personalImageURL,
      ShopTypeEnum? shopType});
  ShopOverviewCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _ShopOverviewCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, ShopOverview, $Out>
    implements ShopOverviewCopyWith<$R, ShopOverview, $Out> {
  _ShopOverviewCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<ShopOverview> $mapper =
      ShopOverviewMapper.ensureInitialized();
  @override
  $R call(
          {String? shopId,
          String? shopName,
          String? personalImageURL,
          ShopTypeEnum? shopType}) =>
      $apply(FieldCopyWithData({
        if (shopId != null) #shopId: shopId,
        if (shopName != null) #shopName: shopName,
        if (personalImageURL != null) #personalImageURL: personalImageURL,
        if (shopType != null) #shopType: shopType
      }));
  @override
  ShopOverview $make(CopyWithData data) => ShopOverview(
      shopId: data.get(#shopId, or: $value.shopId),
      shopName: data.get(#shopName, or: $value.shopName),
      personalImageURL:
          data.get(#personalImageURL, or: $value.personalImageURL),
      shopType: data.get(#shopType, or: $value.shopType));

  @override
  ShopOverviewCopyWith<$R2, ShopOverview, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _ShopOverviewCopyWithImpl($value, $cast, t);
}
