// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'Product.dart';

class ProductDTOMapper extends ClassMapperBase<ProductDTO> {
  ProductDTOMapper._();

  static ProductDTOMapper? _instance;
  static ProductDTOMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = ProductDTOMapper._());
      LocalizedStringMapper.ensureInitialized();
      ShopTypeEnumMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'ProductDTO';

  static String _$productId(ProductDTO v) => v.productId;
  static const Field<ProductDTO, String> _f$productId =
      Field('productId', _$productId);
  static LocalizedString _$name(ProductDTO v) => v.name;
  static const Field<ProductDTO, LocalizedString> _f$name =
      Field('name', _$name);
  static LocalizedString _$description(ProductDTO v) => v.description;
  static const Field<ProductDTO, LocalizedString> _f$description =
      Field('description', _$description);
  static double _$price(ProductDTO v) => v.price;
  static const Field<ProductDTO, double> _f$price = Field('price', _$price);
  static String _$shopOverview(ProductDTO v) => v.shopOverview;
  static const Field<ProductDTO, String> _f$shopOverview =
      Field('shopOverview', _$shopOverview);
  static List<String> _$images(ProductDTO v) => v.images;
  static const Field<ProductDTO, List<String>> _f$images =
      Field('images', _$images);
  static bool _$inStock(ProductDTO v) => v.inStock;
  static const Field<ProductDTO, bool> _f$inStock = Field('inStock', _$inStock);
  static bool _$isDeleted(ProductDTO v) => v.isDeleted;
  static const Field<ProductDTO, bool> _f$isDeleted =
      Field('isDeleted', _$isDeleted);
  static ShopTypeEnum _$shopType(ProductDTO v) => v.shopType;
  static const Field<ProductDTO, ShopTypeEnum> _f$shopType =
      Field('shopType', _$shopType);

  @override
  final MappableFields<ProductDTO> fields = const {
    #productId: _f$productId,
    #name: _f$name,
    #description: _f$description,
    #price: _f$price,
    #shopOverview: _f$shopOverview,
    #images: _f$images,
    #inStock: _f$inStock,
    #isDeleted: _f$isDeleted,
    #shopType: _f$shopType,
  };

  static ProductDTO _instantiate(DecodingData data) {
    return ProductDTO(
        productId: data.dec(_f$productId),
        name: data.dec(_f$name),
        description: data.dec(_f$description),
        price: data.dec(_f$price),
        shopOverview: data.dec(_f$shopOverview),
        images: data.dec(_f$images),
        inStock: data.dec(_f$inStock),
        isDeleted: data.dec(_f$isDeleted),
        shopType: data.dec(_f$shopType));
  }

  @override
  final Function instantiate = _instantiate;

  static ProductDTO fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<ProductDTO>(map);
  }

  static ProductDTO fromJson(String json) {
    return ensureInitialized().decodeJson<ProductDTO>(json);
  }
}

mixin ProductDTOMappable {
  String toJson() {
    return ProductDTOMapper.ensureInitialized()
        .encodeJson<ProductDTO>(this as ProductDTO);
  }

  Map<String, dynamic> toMap() {
    return ProductDTOMapper.ensureInitialized()
        .encodeMap<ProductDTO>(this as ProductDTO);
  }

  ProductDTOCopyWith<ProductDTO, ProductDTO, ProductDTO> get copyWith =>
      _ProductDTOCopyWithImpl(this as ProductDTO, $identity, $identity);
  @override
  String toString() {
    return ProductDTOMapper.ensureInitialized()
        .stringifyValue(this as ProductDTO);
  }

  @override
  bool operator ==(Object other) {
    return ProductDTOMapper.ensureInitialized()
        .equalsValue(this as ProductDTO, other);
  }

  @override
  int get hashCode {
    return ProductDTOMapper.ensureInitialized().hashValue(this as ProductDTO);
  }
}

extension ProductDTOValueCopy<$R, $Out>
    on ObjectCopyWith<$R, ProductDTO, $Out> {
  ProductDTOCopyWith<$R, ProductDTO, $Out> get $asProductDTO =>
      $base.as((v, t, t2) => _ProductDTOCopyWithImpl(v, t, t2));
}

abstract class ProductDTOCopyWith<$R, $In extends ProductDTO, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get name;
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get description;
  ListCopyWith<$R, String, ObjectCopyWith<$R, String, String>> get images;
  $R call(
      {String? productId,
      LocalizedString? name,
      LocalizedString? description,
      double? price,
      String? shopOverview,
      List<String>? images,
      bool? inStock,
      bool? isDeleted,
      ShopTypeEnum? shopType});
  ProductDTOCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _ProductDTOCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, ProductDTO, $Out>
    implements ProductDTOCopyWith<$R, ProductDTO, $Out> {
  _ProductDTOCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<ProductDTO> $mapper =
      ProductDTOMapper.ensureInitialized();
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get name =>
      $value.name.copyWith.$chain((v) => call(name: v));
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>
      get description =>
          $value.description.copyWith.$chain((v) => call(description: v));
  @override
  ListCopyWith<$R, String, ObjectCopyWith<$R, String, String>> get images =>
      ListCopyWith($value.images, (v, t) => ObjectCopyWith(v, $identity, t),
          (v) => call(images: v));
  @override
  $R call(
          {String? productId,
          LocalizedString? name,
          LocalizedString? description,
          double? price,
          String? shopOverview,
          List<String>? images,
          bool? inStock,
          bool? isDeleted,
          ShopTypeEnum? shopType}) =>
      $apply(FieldCopyWithData({
        if (productId != null) #productId: productId,
        if (name != null) #name: name,
        if (description != null) #description: description,
        if (price != null) #price: price,
        if (shopOverview != null) #shopOverview: shopOverview,
        if (images != null) #images: images,
        if (inStock != null) #inStock: inStock,
        if (isDeleted != null) #isDeleted: isDeleted,
        if (shopType != null) #shopType: shopType
      }));
  @override
  ProductDTO $make(CopyWithData data) => ProductDTO(
      productId: data.get(#productId, or: $value.productId),
      name: data.get(#name, or: $value.name),
      description: data.get(#description, or: $value.description),
      price: data.get(#price, or: $value.price),
      shopOverview: data.get(#shopOverview, or: $value.shopOverview),
      images: data.get(#images, or: $value.images),
      inStock: data.get(#inStock, or: $value.inStock),
      isDeleted: data.get(#isDeleted, or: $value.isDeleted),
      shopType: data.get(#shopType, or: $value.shopType));

  @override
  ProductDTOCopyWith<$R2, ProductDTO, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _ProductDTOCopyWithImpl($value, $cast, t);
}

class ProductMapper extends ClassMapperBase<Product> {
  ProductMapper._();

  static ProductMapper? _instance;
  static ProductMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = ProductMapper._());
      ShopTypeEnumMapper.ensureInitialized();
      LocalizedStringMapper.ensureInitialized();
      ShopOverviewMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'Product';

  static String _$productId(Product v) => v.productId;
  static const Field<Product, String> _f$productId =
      Field('productId', _$productId);
  static ShopTypeEnum _$shopType(Product v) => v.shopType;
  static const Field<Product, ShopTypeEnum> _f$shopType =
      Field('shopType', _$shopType);
  static LocalizedString _$description(Product v) => v.description;
  static const Field<Product, LocalizedString> _f$description =
      Field('description', _$description);
  static LocalizedString _$name(Product v) => v.name;
  static const Field<Product, LocalizedString> _f$name = Field('name', _$name);
  static double _$price(Product v) => v.price;
  static const Field<Product, double> _f$price = Field('price', _$price);
  static ShopOverview _$shopOverview(Product v) => v.shopOverview;
  static const Field<Product, ShopOverview> _f$shopOverview =
      Field('shopOverview', _$shopOverview);
  static List<String> _$images(Product v) => v.images;
  static const Field<Product, List<String>> _f$images =
      Field('images', _$images);
  static bool _$inStock(Product v) => v.inStock;
  static const Field<Product, bool> _f$inStock = Field('inStock', _$inStock);
  static bool _$isDeleted(Product v) => v.isDeleted;
  static const Field<Product, bool> _f$isDeleted =
      Field('isDeleted', _$isDeleted);

  @override
  final MappableFields<Product> fields = const {
    #productId: _f$productId,
    #shopType: _f$shopType,
    #description: _f$description,
    #name: _f$name,
    #price: _f$price,
    #shopOverview: _f$shopOverview,
    #images: _f$images,
    #inStock: _f$inStock,
    #isDeleted: _f$isDeleted,
  };

  static Product _instantiate(DecodingData data) {
    return Product(
        productId: data.dec(_f$productId),
        shopType: data.dec(_f$shopType),
        description: data.dec(_f$description),
        name: data.dec(_f$name),
        price: data.dec(_f$price),
        shopOverview: data.dec(_f$shopOverview),
        images: data.dec(_f$images),
        inStock: data.dec(_f$inStock),
        isDeleted: data.dec(_f$isDeleted));
  }

  @override
  final Function instantiate = _instantiate;

  static Product fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<Product>(map);
  }

  static Product fromJson(String json) {
    return ensureInitialized().decodeJson<Product>(json);
  }
}

mixin ProductMappable {
  String toJson() {
    return ProductMapper.ensureInitialized()
        .encodeJson<Product>(this as Product);
  }

  Map<String, dynamic> toMap() {
    return ProductMapper.ensureInitialized()
        .encodeMap<Product>(this as Product);
  }

  ProductCopyWith<Product, Product, Product> get copyWith =>
      _ProductCopyWithImpl(this as Product, $identity, $identity);
  @override
  String toString() {
    return ProductMapper.ensureInitialized().stringifyValue(this as Product);
  }

  @override
  bool operator ==(Object other) {
    return ProductMapper.ensureInitialized()
        .equalsValue(this as Product, other);
  }

  @override
  int get hashCode {
    return ProductMapper.ensureInitialized().hashValue(this as Product);
  }
}

extension ProductValueCopy<$R, $Out> on ObjectCopyWith<$R, Product, $Out> {
  ProductCopyWith<$R, Product, $Out> get $asProduct =>
      $base.as((v, t, t2) => _ProductCopyWithImpl(v, t, t2));
}

abstract class ProductCopyWith<$R, $In extends Product, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get description;
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get name;
  ShopOverviewCopyWith<$R, ShopOverview, ShopOverview> get shopOverview;
  ListCopyWith<$R, String, ObjectCopyWith<$R, String, String>> get images;
  $R call(
      {String? productId,
      ShopTypeEnum? shopType,
      LocalizedString? description,
      LocalizedString? name,
      double? price,
      ShopOverview? shopOverview,
      List<String>? images,
      bool? inStock,
      bool? isDeleted});
  ProductCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _ProductCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, Product, $Out>
    implements ProductCopyWith<$R, Product, $Out> {
  _ProductCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<Product> $mapper =
      ProductMapper.ensureInitialized();
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString>
      get description =>
          $value.description.copyWith.$chain((v) => call(description: v));
  @override
  LocalizedStringCopyWith<$R, LocalizedString, LocalizedString> get name =>
      $value.name.copyWith.$chain((v) => call(name: v));
  @override
  ShopOverviewCopyWith<$R, ShopOverview, ShopOverview> get shopOverview =>
      $value.shopOverview.copyWith.$chain((v) => call(shopOverview: v));
  @override
  ListCopyWith<$R, String, ObjectCopyWith<$R, String, String>> get images =>
      ListCopyWith($value.images, (v, t) => ObjectCopyWith(v, $identity, t),
          (v) => call(images: v));
  @override
  $R call(
          {String? productId,
          ShopTypeEnum? shopType,
          LocalizedString? description,
          LocalizedString? name,
          double? price,
          ShopOverview? shopOverview,
          List<String>? images,
          bool? inStock,
          bool? isDeleted}) =>
      $apply(FieldCopyWithData({
        if (productId != null) #productId: productId,
        if (shopType != null) #shopType: shopType,
        if (description != null) #description: description,
        if (name != null) #name: name,
        if (price != null) #price: price,
        if (shopOverview != null) #shopOverview: shopOverview,
        if (images != null) #images: images,
        if (inStock != null) #inStock: inStock,
        if (isDeleted != null) #isDeleted: isDeleted
      }));
  @override
  Product $make(CopyWithData data) => Product(
      productId: data.get(#productId, or: $value.productId),
      shopType: data.get(#shopType, or: $value.shopType),
      description: data.get(#description, or: $value.description),
      name: data.get(#name, or: $value.name),
      price: data.get(#price, or: $value.price),
      shopOverview: data.get(#shopOverview, or: $value.shopOverview),
      images: data.get(#images, or: $value.images),
      inStock: data.get(#inStock, or: $value.inStock),
      isDeleted: data.get(#isDeleted, or: $value.isDeleted));

  @override
  ProductCopyWith<$R2, Product, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t) =>
      _ProductCopyWithImpl($value, $cast, t);
}
