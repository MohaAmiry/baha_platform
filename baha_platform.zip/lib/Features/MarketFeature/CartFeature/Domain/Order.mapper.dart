// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'Order.dart';

class OrderDTOMapper extends ClassMapperBase<OrderDTO> {
  OrderDTOMapper._();

  static OrderDTOMapper? _instance;
  static OrderDTOMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = OrderDTOMapper._());
      CartProductDTOMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'OrderDTO';

  static String _$orderId(OrderDTO v) => v.orderId;
  static const Field<OrderDTO, String> _f$orderId = Field('orderId', _$orderId);
  static DateTime _$orderTime(OrderDTO v) => v.orderTime;
  static const Field<OrderDTO, DateTime> _f$orderTime =
      Field('orderTime', _$orderTime);
  static String _$shopId(OrderDTO v) => v.shopId;
  static const Field<OrderDTO, String> _f$shopId = Field('shopId', _$shopId);
  static String _$customerId(OrderDTO v) => v.customerId;
  static const Field<OrderDTO, String> _f$customerId =
      Field('customerId', _$customerId);
  static List<CartProductDTO> _$products(OrderDTO v) => v.products;
  static const Field<OrderDTO, List<CartProductDTO>> _f$products =
      Field('products', _$products);
  static bool _$takeFromStore(OrderDTO v) => v.takeFromStore;
  static const Field<OrderDTO, bool> _f$takeFromStore =
      Field('takeFromStore', _$takeFromStore);
  static bool? _$state(OrderDTO v) => v.state;
  static const Field<OrderDTO, bool> _f$state =
      Field('state', _$state, opt: true);

  @override
  final MappableFields<OrderDTO> fields = const {
    #orderId: _f$orderId,
    #orderTime: _f$orderTime,
    #shopId: _f$shopId,
    #customerId: _f$customerId,
    #products: _f$products,
    #takeFromStore: _f$takeFromStore,
    #state: _f$state,
  };

  static OrderDTO _instantiate(DecodingData data) {
    return OrderDTO(
        orderId: data.dec(_f$orderId),
        orderTime: data.dec(_f$orderTime),
        shopId: data.dec(_f$shopId),
        customerId: data.dec(_f$customerId),
        products: data.dec(_f$products),
        takeFromStore: data.dec(_f$takeFromStore),
        state: data.dec(_f$state));
  }

  @override
  final Function instantiate = _instantiate;

  static OrderDTO fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<OrderDTO>(map);
  }

  static OrderDTO fromJson(String json) {
    return ensureInitialized().decodeJson<OrderDTO>(json);
  }
}

mixin OrderDTOMappable {
  String toJson() {
    return OrderDTOMapper.ensureInitialized()
        .encodeJson<OrderDTO>(this as OrderDTO);
  }

  Map<String, dynamic> toMap() {
    return OrderDTOMapper.ensureInitialized()
        .encodeMap<OrderDTO>(this as OrderDTO);
  }

  OrderDTOCopyWith<OrderDTO, OrderDTO, OrderDTO> get copyWith =>
      _OrderDTOCopyWithImpl(this as OrderDTO, $identity, $identity);
  @override
  String toString() {
    return OrderDTOMapper.ensureInitialized().stringifyValue(this as OrderDTO);
  }

  @override
  bool operator ==(Object other) {
    return OrderDTOMapper.ensureInitialized()
        .equalsValue(this as OrderDTO, other);
  }

  @override
  int get hashCode {
    return OrderDTOMapper.ensureInitialized().hashValue(this as OrderDTO);
  }
}

extension OrderDTOValueCopy<$R, $Out> on ObjectCopyWith<$R, OrderDTO, $Out> {
  OrderDTOCopyWith<$R, OrderDTO, $Out> get $asOrderDTO =>
      $base.as((v, t, t2) => _OrderDTOCopyWithImpl(v, t, t2));
}

abstract class OrderDTOCopyWith<$R, $In extends OrderDTO, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  ListCopyWith<$R, CartProductDTO,
      CartProductDTOCopyWith<$R, CartProductDTO, CartProductDTO>> get products;
  $R call(
      {String? orderId,
      DateTime? orderTime,
      String? shopId,
      String? customerId,
      List<CartProductDTO>? products,
      bool? takeFromStore,
      bool? state});
  OrderDTOCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _OrderDTOCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, OrderDTO, $Out>
    implements OrderDTOCopyWith<$R, OrderDTO, $Out> {
  _OrderDTOCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<OrderDTO> $mapper =
      OrderDTOMapper.ensureInitialized();
  @override
  ListCopyWith<$R, CartProductDTO,
          CartProductDTOCopyWith<$R, CartProductDTO, CartProductDTO>>
      get products => ListCopyWith($value.products,
          (v, t) => v.copyWith.$chain(t), (v) => call(products: v));
  @override
  $R call(
          {String? orderId,
          DateTime? orderTime,
          String? shopId,
          String? customerId,
          List<CartProductDTO>? products,
          bool? takeFromStore,
          Object? state = $none}) =>
      $apply(FieldCopyWithData({
        if (orderId != null) #orderId: orderId,
        if (orderTime != null) #orderTime: orderTime,
        if (shopId != null) #shopId: shopId,
        if (customerId != null) #customerId: customerId,
        if (products != null) #products: products,
        if (takeFromStore != null) #takeFromStore: takeFromStore,
        if (state != $none) #state: state
      }));
  @override
  OrderDTO $make(CopyWithData data) => OrderDTO(
      orderId: data.get(#orderId, or: $value.orderId),
      orderTime: data.get(#orderTime, or: $value.orderTime),
      shopId: data.get(#shopId, or: $value.shopId),
      customerId: data.get(#customerId, or: $value.customerId),
      products: data.get(#products, or: $value.products),
      takeFromStore: data.get(#takeFromStore, or: $value.takeFromStore),
      state: data.get(#state, or: $value.state));

  @override
  OrderDTOCopyWith<$R2, OrderDTO, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _OrderDTOCopyWithImpl($value, $cast, t);
}

class OrderMapper extends ClassMapperBase<Order> {
  OrderMapper._();

  static OrderMapper? _instance;
  static OrderMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = OrderMapper._());
      ShopOverviewMapper.ensureInitialized();
      UserResponseDTOMapper.ensureInitialized();
      CartProductMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'Order';

  static String _$orderId(Order v) => v.orderId;
  static const Field<Order, String> _f$orderId = Field('orderId', _$orderId);
  static bool _$takeFromStore(Order v) => v.takeFromStore;
  static const Field<Order, bool> _f$takeFromStore =
      Field('takeFromStore', _$takeFromStore);
  static DateTime _$orderTime(Order v) => v.orderTime;
  static const Field<Order, DateTime> _f$orderTime =
      Field('orderTime', _$orderTime);
  static ShopOverview _$shopOverview(Order v) => v.shopOverview;
  static const Field<Order, ShopOverview> _f$shopOverview =
      Field('shopOverview', _$shopOverview);
  static UserResponseDTO _$customerInfo(Order v) => v.customerInfo;
  static const Field<Order, UserResponseDTO> _f$customerInfo =
      Field('customerInfo', _$customerInfo);
  static List<CartProduct> _$products(Order v) => v.products;
  static const Field<Order, List<CartProduct>> _f$products =
      Field('products', _$products);
  static bool? _$state(Order v) => v.state;
  static const Field<Order, bool> _f$state = Field('state', _$state, opt: true);

  @override
  final MappableFields<Order> fields = const {
    #orderId: _f$orderId,
    #takeFromStore: _f$takeFromStore,
    #orderTime: _f$orderTime,
    #shopOverview: _f$shopOverview,
    #customerInfo: _f$customerInfo,
    #products: _f$products,
    #state: _f$state,
  };

  static Order _instantiate(DecodingData data) {
    return Order(
        orderId: data.dec(_f$orderId),
        takeFromStore: data.dec(_f$takeFromStore),
        orderTime: data.dec(_f$orderTime),
        shopOverview: data.dec(_f$shopOverview),
        customerInfo: data.dec(_f$customerInfo),
        products: data.dec(_f$products),
        state: data.dec(_f$state));
  }

  @override
  final Function instantiate = _instantiate;

  static Order fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<Order>(map);
  }

  static Order fromJson(String json) {
    return ensureInitialized().decodeJson<Order>(json);
  }
}

mixin OrderMappable {
  String toJson() {
    return OrderMapper.ensureInitialized().encodeJson<Order>(this as Order);
  }

  Map<String, dynamic> toMap() {
    return OrderMapper.ensureInitialized().encodeMap<Order>(this as Order);
  }

  OrderCopyWith<Order, Order, Order> get copyWith =>
      _OrderCopyWithImpl(this as Order, $identity, $identity);
  @override
  String toString() {
    return OrderMapper.ensureInitialized().stringifyValue(this as Order);
  }

  @override
  bool operator ==(Object other) {
    return OrderMapper.ensureInitialized().equalsValue(this as Order, other);
  }

  @override
  int get hashCode {
    return OrderMapper.ensureInitialized().hashValue(this as Order);
  }
}

extension OrderValueCopy<$R, $Out> on ObjectCopyWith<$R, Order, $Out> {
  OrderCopyWith<$R, Order, $Out> get $asOrder =>
      $base.as((v, t, t2) => _OrderCopyWithImpl(v, t, t2));
}

abstract class OrderCopyWith<$R, $In extends Order, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  ShopOverviewCopyWith<$R, ShopOverview, ShopOverview> get shopOverview;
  UserResponseDTOCopyWith<$R, UserResponseDTO, UserResponseDTO>
      get customerInfo;
  ListCopyWith<$R, CartProduct,
      CartProductCopyWith<$R, CartProduct, CartProduct>> get products;
  $R call(
      {String? orderId,
      bool? takeFromStore,
      DateTime? orderTime,
      ShopOverview? shopOverview,
      UserResponseDTO? customerInfo,
      List<CartProduct>? products,
      bool? state});
  OrderCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _OrderCopyWithImpl<$R, $Out> extends ClassCopyWithBase<$R, Order, $Out>
    implements OrderCopyWith<$R, Order, $Out> {
  _OrderCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<Order> $mapper = OrderMapper.ensureInitialized();
  @override
  ShopOverviewCopyWith<$R, ShopOverview, ShopOverview> get shopOverview =>
      $value.shopOverview.copyWith.$chain((v) => call(shopOverview: v));
  @override
  UserResponseDTOCopyWith<$R, UserResponseDTO, UserResponseDTO>
      get customerInfo =>
          $value.customerInfo.copyWith.$chain((v) => call(customerInfo: v));
  @override
  ListCopyWith<$R, CartProduct,
          CartProductCopyWith<$R, CartProduct, CartProduct>>
      get products => ListCopyWith($value.products,
          (v, t) => v.copyWith.$chain(t), (v) => call(products: v));
  @override
  $R call(
          {String? orderId,
          bool? takeFromStore,
          DateTime? orderTime,
          ShopOverview? shopOverview,
          UserResponseDTO? customerInfo,
          List<CartProduct>? products,
          Object? state = $none}) =>
      $apply(FieldCopyWithData({
        if (orderId != null) #orderId: orderId,
        if (takeFromStore != null) #takeFromStore: takeFromStore,
        if (orderTime != null) #orderTime: orderTime,
        if (shopOverview != null) #shopOverview: shopOverview,
        if (customerInfo != null) #customerInfo: customerInfo,
        if (products != null) #products: products,
        if (state != $none) #state: state
      }));
  @override
  Order $make(CopyWithData data) => Order(
      orderId: data.get(#orderId, or: $value.orderId),
      takeFromStore: data.get(#takeFromStore, or: $value.takeFromStore),
      orderTime: data.get(#orderTime, or: $value.orderTime),
      shopOverview: data.get(#shopOverview, or: $value.shopOverview),
      customerInfo: data.get(#customerInfo, or: $value.customerInfo),
      products: data.get(#products, or: $value.products),
      state: data.get(#state, or: $value.state));

  @override
  OrderCopyWith<$R2, Order, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t) =>
      _OrderCopyWithImpl($value, $cast, t);
}
