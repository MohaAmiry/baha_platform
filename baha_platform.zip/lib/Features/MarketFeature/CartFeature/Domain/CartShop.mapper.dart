// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'CartShop.dart';

class CartShopDTOMapper extends ClassMapperBase<CartShopDTO> {
  CartShopDTOMapper._();

  static CartShopDTOMapper? _instance;
  static CartShopDTOMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = CartShopDTOMapper._());
      CartProductDTOMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'CartShopDTO';

  static String _$shopOverview(CartShopDTO v) => v.shopOverview;
  static const Field<CartShopDTO, String> _f$shopOverview =
      Field('shopOverview', _$shopOverview);
  static bool _$takeFromStore(CartShopDTO v) => v.takeFromStore;
  static const Field<CartShopDTO, bool> _f$takeFromStore =
      Field('takeFromStore', _$takeFromStore);
  static IList<CartProductDTO> _$products(CartShopDTO v) => v.products;
  static const Field<CartShopDTO, IList<CartProductDTO>> _f$products =
      Field('products', _$products);
  static bool? _$state(CartShopDTO v) => v.state;
  static const Field<CartShopDTO, bool> _f$state =
      Field('state', _$state, opt: true);

  @override
  final MappableFields<CartShopDTO> fields = const {
    #shopOverview: _f$shopOverview,
    #takeFromStore: _f$takeFromStore,
    #products: _f$products,
    #state: _f$state,
  };

  static CartShopDTO _instantiate(DecodingData data) {
    return CartShopDTO(
        shopOverview: data.dec(_f$shopOverview),
        takeFromStore: data.dec(_f$takeFromStore),
        products: data.dec(_f$products),
        state: data.dec(_f$state));
  }

  @override
  final Function instantiate = _instantiate;

  static CartShopDTO fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<CartShopDTO>(map);
  }

  static CartShopDTO fromJson(String json) {
    return ensureInitialized().decodeJson<CartShopDTO>(json);
  }
}

mixin CartShopDTOMappable {
  String toJson() {
    return CartShopDTOMapper.ensureInitialized()
        .encodeJson<CartShopDTO>(this as CartShopDTO);
  }

  Map<String, dynamic> toMap() {
    return CartShopDTOMapper.ensureInitialized()
        .encodeMap<CartShopDTO>(this as CartShopDTO);
  }

  CartShopDTOCopyWith<CartShopDTO, CartShopDTO, CartShopDTO> get copyWith =>
      _CartShopDTOCopyWithImpl(this as CartShopDTO, $identity, $identity);
  @override
  String toString() {
    return CartShopDTOMapper.ensureInitialized()
        .stringifyValue(this as CartShopDTO);
  }

  @override
  bool operator ==(Object other) {
    return CartShopDTOMapper.ensureInitialized()
        .equalsValue(this as CartShopDTO, other);
  }

  @override
  int get hashCode {
    return CartShopDTOMapper.ensureInitialized().hashValue(this as CartShopDTO);
  }
}

extension CartShopDTOValueCopy<$R, $Out>
    on ObjectCopyWith<$R, CartShopDTO, $Out> {
  CartShopDTOCopyWith<$R, CartShopDTO, $Out> get $asCartShopDTO =>
      $base.as((v, t, t2) => _CartShopDTOCopyWithImpl(v, t, t2));
}

abstract class CartShopDTOCopyWith<$R, $In extends CartShopDTO, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  $R call(
      {String? shopOverview,
      bool? takeFromStore,
      IList<CartProductDTO>? products,
      bool? state});
  CartShopDTOCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _CartShopDTOCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, CartShopDTO, $Out>
    implements CartShopDTOCopyWith<$R, CartShopDTO, $Out> {
  _CartShopDTOCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<CartShopDTO> $mapper =
      CartShopDTOMapper.ensureInitialized();
  @override
  $R call(
          {String? shopOverview,
          bool? takeFromStore,
          IList<CartProductDTO>? products,
          Object? state = $none}) =>
      $apply(FieldCopyWithData({
        if (shopOverview != null) #shopOverview: shopOverview,
        if (takeFromStore != null) #takeFromStore: takeFromStore,
        if (products != null) #products: products,
        if (state != $none) #state: state
      }));
  @override
  CartShopDTO $make(CopyWithData data) => CartShopDTO(
      shopOverview: data.get(#shopOverview, or: $value.shopOverview),
      takeFromStore: data.get(#takeFromStore, or: $value.takeFromStore),
      products: data.get(#products, or: $value.products),
      state: data.get(#state, or: $value.state));

  @override
  CartShopDTOCopyWith<$R2, CartShopDTO, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _CartShopDTOCopyWithImpl($value, $cast, t);
}

class CartShopMapper extends ClassMapperBase<CartShop> {
  CartShopMapper._();

  static CartShopMapper? _instance;
  static CartShopMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = CartShopMapper._());
      ShopOverviewMapper.ensureInitialized();
      CartProductMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'CartShop';

  static ShopOverview _$shopOverview(CartShop v) => v.shopOverview;
  static const Field<CartShop, ShopOverview> _f$shopOverview =
      Field('shopOverview', _$shopOverview);
  static bool _$takeFromStore(CartShop v) => v.takeFromStore;
  static const Field<CartShop, bool> _f$takeFromStore =
      Field('takeFromStore', _$takeFromStore);
  static IList<CartProduct> _$products(CartShop v) => v.products;
  static const Field<CartShop, IList<CartProduct>> _f$products =
      Field('products', _$products);
  static bool? _$state(CartShop v) => v.state;
  static const Field<CartShop, bool> _f$state =
      Field('state', _$state, opt: true);

  @override
  final MappableFields<CartShop> fields = const {
    #shopOverview: _f$shopOverview,
    #takeFromStore: _f$takeFromStore,
    #products: _f$products,
    #state: _f$state,
  };

  static CartShop _instantiate(DecodingData data) {
    return CartShop(
        shopOverview: data.dec(_f$shopOverview),
        takeFromStore: data.dec(_f$takeFromStore),
        products: data.dec(_f$products),
        state: data.dec(_f$state));
  }

  @override
  final Function instantiate = _instantiate;

  static CartShop fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<CartShop>(map);
  }

  static CartShop fromJson(String json) {
    return ensureInitialized().decodeJson<CartShop>(json);
  }
}

mixin CartShopMappable {
  String toJson() {
    return CartShopMapper.ensureInitialized()
        .encodeJson<CartShop>(this as CartShop);
  }

  Map<String, dynamic> toMap() {
    return CartShopMapper.ensureInitialized()
        .encodeMap<CartShop>(this as CartShop);
  }

  CartShopCopyWith<CartShop, CartShop, CartShop> get copyWith =>
      _CartShopCopyWithImpl(this as CartShop, $identity, $identity);
  @override
  String toString() {
    return CartShopMapper.ensureInitialized().stringifyValue(this as CartShop);
  }

  @override
  bool operator ==(Object other) {
    return CartShopMapper.ensureInitialized()
        .equalsValue(this as CartShop, other);
  }

  @override
  int get hashCode {
    return CartShopMapper.ensureInitialized().hashValue(this as CartShop);
  }
}

extension CartShopValueCopy<$R, $Out> on ObjectCopyWith<$R, CartShop, $Out> {
  CartShopCopyWith<$R, CartShop, $Out> get $asCartShop =>
      $base.as((v, t, t2) => _CartShopCopyWithImpl(v, t, t2));
}

abstract class CartShopCopyWith<$R, $In extends CartShop, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  ShopOverviewCopyWith<$R, ShopOverview, ShopOverview> get shopOverview;
  $R call(
      {ShopOverview? shopOverview,
      bool? takeFromStore,
      IList<CartProduct>? products,
      bool? state});
  CartShopCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _CartShopCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, CartShop, $Out>
    implements CartShopCopyWith<$R, CartShop, $Out> {
  _CartShopCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<CartShop> $mapper =
      CartShopMapper.ensureInitialized();
  @override
  ShopOverviewCopyWith<$R, ShopOverview, ShopOverview> get shopOverview =>
      $value.shopOverview.copyWith.$chain((v) => call(shopOverview: v));
  @override
  $R call(
          {ShopOverview? shopOverview,
          bool? takeFromStore,
          IList<CartProduct>? products,
          Object? state = $none}) =>
      $apply(FieldCopyWithData({
        if (shopOverview != null) #shopOverview: shopOverview,
        if (takeFromStore != null) #takeFromStore: takeFromStore,
        if (products != null) #products: products,
        if (state != $none) #state: state
      }));
  @override
  CartShop $make(CopyWithData data) => CartShop(
      shopOverview: data.get(#shopOverview, or: $value.shopOverview),
      takeFromStore: data.get(#takeFromStore, or: $value.takeFromStore),
      products: data.get(#products, or: $value.products),
      state: data.get(#state, or: $value.state));

  @override
  CartShopCopyWith<$R2, CartShop, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _CartShopCopyWithImpl($value, $cast, t);
}
