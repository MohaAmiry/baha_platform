// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'CartProduct.dart';

class CartProductDTOMapper extends ClassMapperBase<CartProductDTO> {
  CartProductDTOMapper._();

  static CartProductDTOMapper? _instance;
  static CartProductDTOMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = CartProductDTOMapper._());
    }
    return _instance!;
  }

  @override
  final String id = 'CartProductDTO';

  static String _$productId(CartProductDTO v) => v.productId;
  static const Field<CartProductDTO, String> _f$productId =
      Field('productId', _$productId);
  static int _$amount(CartProductDTO v) => v.amount;
  static const Field<CartProductDTO, int> _f$amount = Field('amount', _$amount);

  @override
  final MappableFields<CartProductDTO> fields = const {
    #productId: _f$productId,
    #amount: _f$amount,
  };

  static CartProductDTO _instantiate(DecodingData data) {
    return CartProductDTO(
        productId: data.dec(_f$productId), amount: data.dec(_f$amount));
  }

  @override
  final Function instantiate = _instantiate;

  static CartProductDTO fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<CartProductDTO>(map);
  }

  static CartProductDTO fromJson(String json) {
    return ensureInitialized().decodeJson<CartProductDTO>(json);
  }
}

mixin CartProductDTOMappable {
  String toJson() {
    return CartProductDTOMapper.ensureInitialized()
        .encodeJson<CartProductDTO>(this as CartProductDTO);
  }

  Map<String, dynamic> toMap() {
    return CartProductDTOMapper.ensureInitialized()
        .encodeMap<CartProductDTO>(this as CartProductDTO);
  }

  CartProductDTOCopyWith<CartProductDTO, CartProductDTO, CartProductDTO>
      get copyWith => _CartProductDTOCopyWithImpl(
          this as CartProductDTO, $identity, $identity);
  @override
  String toString() {
    return CartProductDTOMapper.ensureInitialized()
        .stringifyValue(this as CartProductDTO);
  }

  @override
  bool operator ==(Object other) {
    return CartProductDTOMapper.ensureInitialized()
        .equalsValue(this as CartProductDTO, other);
  }

  @override
  int get hashCode {
    return CartProductDTOMapper.ensureInitialized()
        .hashValue(this as CartProductDTO);
  }
}

extension CartProductDTOValueCopy<$R, $Out>
    on ObjectCopyWith<$R, CartProductDTO, $Out> {
  CartProductDTOCopyWith<$R, CartProductDTO, $Out> get $asCartProductDTO =>
      $base.as((v, t, t2) => _CartProductDTOCopyWithImpl(v, t, t2));
}

abstract class CartProductDTOCopyWith<$R, $In extends CartProductDTO, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  $R call({String? productId, int? amount});
  CartProductDTOCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(
      Then<$Out2, $R2> t);
}

class _CartProductDTOCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, CartProductDTO, $Out>
    implements CartProductDTOCopyWith<$R, CartProductDTO, $Out> {
  _CartProductDTOCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<CartProductDTO> $mapper =
      CartProductDTOMapper.ensureInitialized();
  @override
  $R call({String? productId, int? amount}) => $apply(FieldCopyWithData({
        if (productId != null) #productId: productId,
        if (amount != null) #amount: amount
      }));
  @override
  CartProductDTO $make(CopyWithData data) => CartProductDTO(
      productId: data.get(#productId, or: $value.productId),
      amount: data.get(#amount, or: $value.amount));

  @override
  CartProductDTOCopyWith<$R2, CartProductDTO, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _CartProductDTOCopyWithImpl($value, $cast, t);
}

class CartProductMapper extends ClassMapperBase<CartProduct> {
  CartProductMapper._();

  static CartProductMapper? _instance;
  static CartProductMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = CartProductMapper._());
      ProductMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'CartProduct';

  static Product _$product(CartProduct v) => v.product;
  static const Field<CartProduct, Product> _f$product =
      Field('product', _$product);
  static int _$amount(CartProduct v) => v.amount;
  static const Field<CartProduct, int> _f$amount = Field('amount', _$amount);

  @override
  final MappableFields<CartProduct> fields = const {
    #product: _f$product,
    #amount: _f$amount,
  };

  static CartProduct _instantiate(DecodingData data) {
    return CartProduct(
        product: data.dec(_f$product), amount: data.dec(_f$amount));
  }

  @override
  final Function instantiate = _instantiate;

  static CartProduct fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<CartProduct>(map);
  }

  static CartProduct fromJson(String json) {
    return ensureInitialized().decodeJson<CartProduct>(json);
  }
}

mixin CartProductMappable {
  String toJson() {
    return CartProductMapper.ensureInitialized()
        .encodeJson<CartProduct>(this as CartProduct);
  }

  Map<String, dynamic> toMap() {
    return CartProductMapper.ensureInitialized()
        .encodeMap<CartProduct>(this as CartProduct);
  }

  CartProductCopyWith<CartProduct, CartProduct, CartProduct> get copyWith =>
      _CartProductCopyWithImpl(this as CartProduct, $identity, $identity);
  @override
  String toString() {
    return CartProductMapper.ensureInitialized()
        .stringifyValue(this as CartProduct);
  }

  @override
  bool operator ==(Object other) {
    return CartProductMapper.ensureInitialized()
        .equalsValue(this as CartProduct, other);
  }

  @override
  int get hashCode {
    return CartProductMapper.ensureInitialized().hashValue(this as CartProduct);
  }
}

extension CartProductValueCopy<$R, $Out>
    on ObjectCopyWith<$R, CartProduct, $Out> {
  CartProductCopyWith<$R, CartProduct, $Out> get $asCartProduct =>
      $base.as((v, t, t2) => _CartProductCopyWithImpl(v, t, t2));
}

abstract class CartProductCopyWith<$R, $In extends CartProduct, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  ProductCopyWith<$R, Product, Product> get product;
  $R call({Product? product, int? amount});
  CartProductCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _CartProductCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, CartProduct, $Out>
    implements CartProductCopyWith<$R, CartProduct, $Out> {
  _CartProductCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<CartProduct> $mapper =
      CartProductMapper.ensureInitialized();
  @override
  ProductCopyWith<$R, Product, Product> get product =>
      $value.product.copyWith.$chain((v) => call(product: v));
  @override
  $R call({Product? product, int? amount}) => $apply(FieldCopyWithData({
        if (product != null) #product: product,
        if (amount != null) #amount: amount
      }));
  @override
  CartProduct $make(CopyWithData data) => CartProduct(
      product: data.get(#product, or: $value.product),
      amount: data.get(#amount, or: $value.amount));

  @override
  CartProductCopyWith<$R2, CartProduct, $Out2> $chain<$R2, $Out2>(
          Then<$Out2, $R2> t) =>
      _CartProductCopyWithImpl($value, $cast, t);
}
