// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'Cart.dart';

class CartDTOMapper extends ClassMapperBase<CartDTO> {
  CartDTOMapper._();

  static CartDTOMapper? _instance;
  static CartDTOMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = CartDTOMapper._());
      CartShopDTOMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'CartDTO';

  static String _$customerId(CartDTO v) => v.customerId;
  static const Field<CartDTO, String> _f$customerId =
      Field('customerId', _$customerId);
  static IList<CartShopDTO> _$cartShops(CartDTO v) => v.cartShops;
  static const Field<CartDTO, IList<CartShopDTO>> _f$cartShops =
      Field('cartShops', _$cartShops);

  @override
  final MappableFields<CartDTO> fields = const {
    #customerId: _f$customerId,
    #cartShops: _f$cartShops,
  };

  static CartDTO _instantiate(DecodingData data) {
    return CartDTO(
        customerId: data.dec(_f$customerId), cartShops: data.dec(_f$cartShops));
  }

  @override
  final Function instantiate = _instantiate;

  static CartDTO fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<CartDTO>(map);
  }

  static CartDTO fromJson(String json) {
    return ensureInitialized().decodeJson<CartDTO>(json);
  }
}

mixin CartDTOMappable {
  String toJson() {
    return CartDTOMapper.ensureInitialized()
        .encodeJson<CartDTO>(this as CartDTO);
  }

  Map<String, dynamic> toMap() {
    return CartDTOMapper.ensureInitialized()
        .encodeMap<CartDTO>(this as CartDTO);
  }

  CartDTOCopyWith<CartDTO, CartDTO, CartDTO> get copyWith =>
      _CartDTOCopyWithImpl(this as CartDTO, $identity, $identity);
  @override
  String toString() {
    return CartDTOMapper.ensureInitialized().stringifyValue(this as CartDTO);
  }

  @override
  bool operator ==(Object other) {
    return CartDTOMapper.ensureInitialized()
        .equalsValue(this as CartDTO, other);
  }

  @override
  int get hashCode {
    return CartDTOMapper.ensureInitialized().hashValue(this as CartDTO);
  }
}

extension CartDTOValueCopy<$R, $Out> on ObjectCopyWith<$R, CartDTO, $Out> {
  CartDTOCopyWith<$R, CartDTO, $Out> get $asCartDTO =>
      $base.as((v, t, t2) => _CartDTOCopyWithImpl(v, t, t2));
}

abstract class CartDTOCopyWith<$R, $In extends CartDTO, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  $R call({String? customerId, IList<CartShopDTO>? cartShops});
  CartDTOCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _CartDTOCopyWithImpl<$R, $Out>
    extends ClassCopyWithBase<$R, CartDTO, $Out>
    implements CartDTOCopyWith<$R, CartDTO, $Out> {
  _CartDTOCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<CartDTO> $mapper =
      CartDTOMapper.ensureInitialized();
  @override
  $R call({String? customerId, IList<CartShopDTO>? cartShops}) =>
      $apply(FieldCopyWithData({
        if (customerId != null) #customerId: customerId,
        if (cartShops != null) #cartShops: cartShops
      }));
  @override
  CartDTO $make(CopyWithData data) => CartDTO(
      customerId: data.get(#customerId, or: $value.customerId),
      cartShops: data.get(#cartShops, or: $value.cartShops));

  @override
  CartDTOCopyWith<$R2, CartDTO, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t) =>
      _CartDTOCopyWithImpl($value, $cast, t);
}

class CartMapper extends ClassMapperBase<Cart> {
  CartMapper._();

  static CartMapper? _instance;
  static CartMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = CartMapper._());
      CartShopMapper.ensureInitialized();
    }
    return _instance!;
  }

  @override
  final String id = 'Cart';

  static String _$customerId(Cart v) => v.customerId;
  static const Field<Cart, String> _f$customerId =
      Field('customerId', _$customerId);
  static IList<CartShop> _$cartShops(Cart v) => v.cartShops;
  static const Field<Cart, IList<CartShop>> _f$cartShops =
      Field('cartShops', _$cartShops);

  @override
  final MappableFields<Cart> fields = const {
    #customerId: _f$customerId,
    #cartShops: _f$cartShops,
  };

  static Cart _instantiate(DecodingData data) {
    return Cart(
        customerId: data.dec(_f$customerId), cartShops: data.dec(_f$cartShops));
  }

  @override
  final Function instantiate = _instantiate;

  static Cart fromMap(Map<String, dynamic> map) {
    return ensureInitialized().decodeMap<Cart>(map);
  }

  static Cart fromJson(String json) {
    return ensureInitialized().decodeJson<Cart>(json);
  }
}

mixin CartMappable {
  String toJson() {
    return CartMapper.ensureInitialized().encodeJson<Cart>(this as Cart);
  }

  Map<String, dynamic> toMap() {
    return CartMapper.ensureInitialized().encodeMap<Cart>(this as Cart);
  }

  CartCopyWith<Cart, Cart, Cart> get copyWith =>
      _CartCopyWithImpl(this as Cart, $identity, $identity);
  @override
  String toString() {
    return CartMapper.ensureInitialized().stringifyValue(this as Cart);
  }

  @override
  bool operator ==(Object other) {
    return CartMapper.ensureInitialized().equalsValue(this as Cart, other);
  }

  @override
  int get hashCode {
    return CartMapper.ensureInitialized().hashValue(this as Cart);
  }
}

extension CartValueCopy<$R, $Out> on ObjectCopyWith<$R, Cart, $Out> {
  CartCopyWith<$R, Cart, $Out> get $asCart =>
      $base.as((v, t, t2) => _CartCopyWithImpl(v, t, t2));
}

abstract class CartCopyWith<$R, $In extends Cart, $Out>
    implements ClassCopyWith<$R, $In, $Out> {
  $R call({String? customerId, IList<CartShop>? cartShops});
  CartCopyWith<$R2, $In, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t);
}

class _CartCopyWithImpl<$R, $Out> extends ClassCopyWithBase<$R, Cart, $Out>
    implements CartCopyWith<$R, Cart, $Out> {
  _CartCopyWithImpl(super.value, super.then, super.then2);

  @override
  late final ClassMapperBase<Cart> $mapper = CartMapper.ensureInitialized();
  @override
  $R call({String? customerId, IList<CartShop>? cartShops}) =>
      $apply(FieldCopyWithData({
        if (customerId != null) #customerId: customerId,
        if (cartShops != null) #cartShops: cartShops
      }));
  @override
  Cart $make(CopyWithData data) => Cart(
      customerId: data.get(#customerId, or: $value.customerId),
      cartShops: data.get(#cartShops, or: $value.cartShops));

  @override
  CartCopyWith<$R2, Cart, $Out2> $chain<$R2, $Out2>(Then<$Out2, $R2> t) =>
      _CartCopyWithImpl($value, $cast, t);
}
