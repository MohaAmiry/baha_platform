// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'CartNotifiers.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$customerCartHash() => r'78ea8e7219fa4d421e4f72ed04d09ded9bfe34c5';

/// See also [CustomerCart].
@ProviderFor(CustomerCart)
final customerCartProvider =
    AutoDisposeStreamNotifierProvider<CustomerCart, Cart>.internal(
  CustomerCart.new,
  name: r'customerCartProvider',
  debugGetCreateSourceHash:
      const bool.fromEnvironment('dart.vm.product') ? null : _$customerCartHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$CustomerCart = AutoDisposeStreamNotifier<Cart>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
