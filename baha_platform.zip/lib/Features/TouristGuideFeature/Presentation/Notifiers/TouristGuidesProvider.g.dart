// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'TouristGuidesProvider.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$touristGuidesListHash() => r'e046cb58eae432f6b9147bb334414481b2a328ae';

/// See also [touristGuidesList].
@ProviderFor(touristGuidesList)
final touristGuidesListProvider =
    AutoDisposeStreamProvider<List<UserResponseDTO>>.internal(
  touristGuidesList,
  name: r'touristGuidesListProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$touristGuidesListHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef TouristGuidesListRef
    = AutoDisposeStreamProviderRef<List<UserResponseDTO>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
