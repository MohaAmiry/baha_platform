@MappableLib(generateInitializerForScope: InitializerScope.package)
library main;

import 'package:dart_mappable/dart_mappable.dart';
