// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'LocalizationRepository.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$localizationRepositoryHash() =>
    r'504d84210e69c6606ea2fd3b5ab1084fcb296ee3';

/// See also [localizationRepository].
@ProviderFor(localizationRepository)
final localizationRepositoryProvider =
    FutureProvider<_LocalizationRepository>.internal(
  localizationRepository,
  name: r'localizationRepositoryProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$localizationRepositoryHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

@Deprecated('Will be removed in 3.0. Use Ref instead')
// ignore: unused_element
typedef LocalizationRepositoryRef = FutureProviderRef<_LocalizationRepository>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
