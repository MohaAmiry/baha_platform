// coverage:ignore-file
// GENERATED CODE - DO NOT MODIFY BY HAND
// ignore_for_file: type=lint
// ignore_for_file: unused_element, unnecessary_cast, override_on_non_overriding_member
// ignore_for_file: strict_raw_type, inference_failure_on_untyped_parameter

part of 'Enums.dart';

class ContentTypeMapper extends EnumMapper<ContentType> {
  ContentTypeMapper._();

  static ContentTypeMapper? _instance;
  static ContentTypeMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = ContentTypeMapper._());
    }
    return _instance!;
  }

  static ContentType fromValue(dynamic value) {
    ensureInitialized();
    return MapperContainer.globals.fromValue(value);
  }

  @override
  ContentType decode(dynamic value) {
    switch (value) {
      case 'forests':
        return ContentType.forests;
      case 'parks':
        return ContentType.parks;
      case 'archaeologicalVillages':
        return ContentType.archaeologicalVillages;
      case 'farms':
        return ContentType.farms;
      case 'hotels':
        return ContentType.hotels;
      case 'cafes':
        return ContentType.cafes;
      case 'resorts':
        return ContentType.resorts;
      case 'festivals':
        return ContentType.festivals;
      default:
        throw MapperException.unknownEnumValue(value);
    }
  }

  @override
  dynamic encode(ContentType self) {
    switch (self) {
      case ContentType.forests:
        return 'forests';
      case ContentType.parks:
        return 'parks';
      case ContentType.archaeologicalVillages:
        return 'archaeologicalVillages';
      case ContentType.farms:
        return 'farms';
      case ContentType.hotels:
        return 'hotels';
      case ContentType.cafes:
        return 'cafes';
      case ContentType.resorts:
        return 'resorts';
      case ContentType.festivals:
        return 'festivals';
    }
  }
}

extension ContentTypeMapperExtension on ContentType {
  String toValue() {
    ContentTypeMapper.ensureInitialized();
    return MapperContainer.globals.toValue<ContentType>(this) as String;
  }
}

class TimeTypeMapper extends EnumMapper<TimeType> {
  TimeTypeMapper._();

  static TimeTypeMapper? _instance;
  static TimeTypeMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = TimeTypeMapper._());
    }
    return _instance!;
  }

  static TimeType fromValue(dynamic value) {
    ensureInitialized();
    return MapperContainer.globals.fromValue(value);
  }

  @override
  TimeType decode(dynamic value) {
    switch (value) {
      case 'days':
        return TimeType.days;
      case 'months':
        return TimeType.months;
      case 'years':
        return TimeType.years;
      default:
        throw MapperException.unknownEnumValue(value);
    }
  }

  @override
  dynamic encode(TimeType self) {
    switch (self) {
      case TimeType.days:
        return 'days';
      case TimeType.months:
        return 'months';
      case TimeType.years:
        return 'years';
    }
  }
}

extension TimeTypeMapperExtension on TimeType {
  String toValue() {
    TimeTypeMapper.ensureInitialized();
    return MapperContainer.globals.toValue<TimeType>(this) as String;
  }
}

class StoryTimeTypeMapper extends EnumMapper<StoryTimeType> {
  StoryTimeTypeMapper._();

  static StoryTimeTypeMapper? _instance;
  static StoryTimeTypeMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = StoryTimeTypeMapper._());
    }
    return _instance!;
  }

  static StoryTimeType fromValue(dynamic value) {
    ensureInitialized();
    return MapperContainer.globals.fromValue(value);
  }

  @override
  StoryTimeType decode(dynamic value) {
    switch (value) {
      case 'second':
        return StoryTimeType.second;
      case 'minute':
        return StoryTimeType.minute;
      case 'hour':
        return StoryTimeType.hour;
      default:
        throw MapperException.unknownEnumValue(value);
    }
  }

  @override
  dynamic encode(StoryTimeType self) {
    switch (self) {
      case StoryTimeType.second:
        return 'second';
      case StoryTimeType.minute:
        return 'minute';
      case StoryTimeType.hour:
        return 'hour';
    }
  }
}

extension StoryTimeTypeMapperExtension on StoryTimeType {
  String toValue() {
    StoryTimeTypeMapper.ensureInitialized();
    return MapperContainer.globals.toValue<StoryTimeType>(this) as String;
  }
}

class TimeUnitMapper extends EnumMapper<TimeUnit> {
  TimeUnitMapper._();

  static TimeUnitMapper? _instance;
  static TimeUnitMapper ensureInitialized() {
    if (_instance == null) {
      MapperContainer.globals.use(_instance = TimeUnitMapper._());
    }
    return _instance!;
  }

  static TimeUnit fromValue(dynamic value) {
    ensureInitialized();
    return MapperContainer.globals.fromValue(value);
  }

  @override
  TimeUnit decode(dynamic value) {
    switch (value) {
      case 'am':
        return TimeUnit.am;
      case 'pm':
        return TimeUnit.pm;
      default:
        throw MapperException.unknownEnumValue(value);
    }
  }

  @override
  dynamic encode(TimeUnit self) {
    switch (self) {
      case TimeUnit.am:
        return 'am';
      case TimeUnit.pm:
        return 'pm';
    }
  }
}

extension TimeUnitMapperExtension on TimeUnit {
  String toValue() {
    TimeUnitMapper.ensureInitialized();
    return MapperContainer.globals.toValue<TimeUnit>(this) as String;
  }
}
